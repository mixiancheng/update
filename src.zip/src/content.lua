_str字符串  _img 图片  _edi=填空

--content  that girl?图片【填空长度10 内容 tom】

content=[
    {
        "type": "_str",
        "value": "that girl?"
    },--字符串
    {
        "type": "_img",
        "url": "imgUrl",
        "value": "imgName.png"
    },--图片
    {
        "type": "_edi",
        "value": 10
        "result"="tom" --填空答案
    }--填空
]

results=[
    {
        "type": "_str",
        "value": "A.adadadasdasda"
    },
    {
        "type": "_str",
        "isResult": "true”,--本题答案选线
        "value": "B.adadadasdasda"
    },
    {
        "type": "_str",
        "value": "C.adadadasdasda"
    },
    {--选项为图片
        "type": "_img",
        "url": "imgUrl",
        "value": "imgName.png"
    }
]