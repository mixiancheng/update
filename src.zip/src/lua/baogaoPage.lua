-------------------------------------
--  StartGame Test
-------------------------------------
local baogaoPage = class("baogaoPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
baogaoPage.__index = baogaoPage
baogaoPage._uilayer = nil
function baogaoPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function baogaoPage:onEnter()
   
end

function baogaoPage:onExit()
end

function baogaoPage.create()
    local scene = baogaoPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function baogaoPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("baogaoSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
    _name:setString(_title)
    local _button_back=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
    _button_back:addClickEventListener(function ( ... )
        -- body
        require 'control' goUI(_SceneInfo_old)
    end)
    self:initUiData()
    -- self._uilayer:runAction( cc.Sequence:create(cc.DelayTime:create(2),cc.CallFunc:create(nextScene)))
    return self._uilayer
end
function baogaoPage:initUiData(  )
    -- body
    local _baseInfo=_properInfoDetail.baseInfo[1]
    local _properInfo=_properInfoDetail.properInfoDetail
    local _knowledgePointDetail=_properInfoDetail.knowledgePointDetail
    local _testTime=_baseInfo['testtime'] or ''
    local _testTimeLong=_baseInfo['testtimeLong'] or ''
    local _username=_baseInfo['username'] or ''
    local _sex=_baseInfo['sex'] or ''
    local _comprehensivedesc=_baseInfo['comprehensivedesc'] or ''
    local _score=_baseInfo['score'] or ''
    local _grade=_baseInfo['grade'] or ''
    local _hobbies=_baseInfo['hobbies'] or ''
    local _schoolname=_baseInfo['schoolname'] or ''
    local _city=_baseInfo['city'] or ''
    local _scoreRank=_baseInfo['scoreRank'] or ''
    local views=self._uilayer:getChildByName('PageView')
    local Panel_6_item=self._uilayer:getChildByName('FileNode_item'):getChildByName('item_node')
    local panel_1=views:getChildByName('Panel_1')
    local panel_1_time = panel_1:getChildByName('time')
    local panel_1_timeLong = panel_1:getChildByName('timeLong')
    panel_1_time:setText(_testTime)
    panel_1_timeLong:setText(_testTimeLong)
    local panel_2=views:getChildByName('Panel_2')
    local panel_3=views:getChildByName('Panel_3')
    local panel_3_name=panel_3:getChildByName('Text_name')
    local panel_3_sex=panel_3:getChildByName('Text_sex')
    local panel_3_level=panel_3:getChildByName('Text_level')
    local panel_3_type=panel_3:getChildByName('Text_type')
    panel_3_name:setText(_username)
    panel_3_sex:setText(_sex)
    panel_3_level:setText(_grade)
    local panel_4=views:getChildByName('Panel_4')
    local panel_4_schoolName=panel_4:getChildByName('Panel_1'):getChildByName('Text_school')
    local panel_4_city=panel_4:getChildByName('Panel_1'):getChildByName('Text_city')
    local panel_4_scoreRank=panel_4:getChildByName('Panel_2'):getChildByName('Text_rank')
    local panel_4_score=panel_4:getChildByName('Panel_2'):getChildByName('Text_score')
    local panel_4_hobbies=panel_4:getChildByName('Panel_3'):getChildByName('Text_one')
    local panel_4_comprehensiveDesc=panel_4:getChildByName('Panel_3'):getChildByName('Text_two')
    panel_4_schoolName:setText(_schoolname)
    panel_4_city:setText(_city)
    panel_4_scoreRank:setText(_scoreRank)
    panel_4_score:setText(_score)
    panel_4_hobbies:setText(_hobbies)
    panel_4_comprehensiveDesc:setText(_comprehensiveDesc)
    local panel_5=views:getChildByName('Panel_5')
    local _pers=panel_5:getChildByName('Panel_ex')
    for i,v in ipairs(_properInfo) do
       local name=v['part']
       local per=v['accuracy'] or 0
       
       if name~=nil and per~=nil then 
        local _node=_pers:getChildByName(name)
        _node:setVisible(true)
       _node:setPercent(per)
       end 
    end
    local panel_6=views:getChildByName('Panel_6')
    local panel_6_listview=panel_6:getChildByName('ListView')
    for i,v in ipairs(_knowledgePointDetail) do
      local _knowledgePointID=v['knowledgepointid'] or ''
      local _knowledgePointName=v['knowledgepointname'] or ''
      local _accuracy=v['knowledgepointaccuracy'] or 0
      local _items=Panel_6_item:clone()
        local _per=_items:getChildByName('LoadingBar')
        local _name=_items:getChildByName('name')
        _name:setText(_knowledgePointName)
        local Text_per=_items:getChildByName('Text_per_0')
        Text_per:setText(_accuracy.."%")
        _per:setPercent(_accuracy)
        panel_6_listview:pushBackCustomItem(_items)
    end
    local panel_7=views:getChildByName('Panel_7')
end
function baogaoPage:initButton()
-- local listView = self._uilayer:getChildByName("ListView"); --这是主界面中的Listveiew
-- self.item_node = self._uilayer:getChildByName("item_node"); -- 这里是一个做好的item项
-- self.item_node1 = self.item_node:getChildByName("Panel"); -- 这里是一个做好
-- self._item={}
--    for i = 1, 10 do
--     print('--------------------------')
--         self._item[i] = self.item_node1:clone();
--         listView:pushBackCustomItem(self._item[i]);
--     end
end
function baogaoPageCreate()
    return baogaoPage.create()
end



