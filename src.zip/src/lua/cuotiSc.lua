--我的记录
local cuotiPage = class("cuotiPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
cuotiPage.__index = cuotiPage
cuotiPage._uilayer = nil
function cuotiPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function cuotiPage:onEnter()
   
end

function cuotiPage:onExit()
end

function cuotiPage.create()
    local scene = cuotiPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function cuotiPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("cuotiSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    self:initList()
    return self._uilayer
end
function cuotiPage:initButton()
    -- body
   require "control" 
    local ButtonBack=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
   ButtonBack:addClickEventListener(function() goUI(_allUI.mainPage) end)--返回主页
   local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
   _name:setString(_title)
end
function cuotiPage:initList()--初始化list列表
    -- body
    local _listView=self._uilayer:getChildByName('ListView')
    local _node=self._uilayer:getChildByName('item_node')
    local _item=_node:getChildByName('item_node')
    -- local _name=_item:getChildByName('name')
    -- local _button_test=_item:getChildByName('Button_test')
    -- local _button_lock=_item:getChildByName('Button_lock')
    for i = 1, #_questionDetails do
        local _temp=_questionDetails[i]
        local knowledgename=_temp['knowledgename']
        local errorsource=_temp['errorsource']
        local questionnumber=_temp['questionnumber']
        local answernumber=_temp['answernumber']
        local examLevel=_temp['examlevel']
        local courseId=_temp['courseid']
        local knowledgeId=_temp['knowledgeid']
        local questionType=_temp['questiontype']
        print('questionType'..questionType)
         local _items = _item:clone();
         local _name=_items:getChildByName('name')
         _name:setString(knowledgename)
         local _type=_items:getChildByName('type')
         _type:setString(errorsource)
         local _per=_items:getChildByName('per')
         _per:setString(questionnumber.."/"..answernumber)
         local _button_lx=_items:getChildByName('Button_lx')
         _button_lx:addClickEventListener(function ( ... )
             -- body
             get_questionList(questionType,examLevel,courseId,knowledgeId,function ( code,data )
                 -- body
                 -- print("get_questionList_cuoti"..data)
    --              path = cc.FileUtils:getInstance():getWritablePath()
    -- local f = io.open(path..'cuoti.txt', "w+")
    -- f:write(data);
    -- f:close();
                 if code==200 then 
                 require "control" goUI(_allUI.myLianXiPage)
                 end
             end)
             -- 
         end)
        _listView:pushBackCustomItem(_items);
    end
end
function cuotiPageCreate()
    return cuotiPage.create()
end



