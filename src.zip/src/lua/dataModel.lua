function get_model( ... )
    -- body
    local _table={
    "paperParts": [
        {
            "quesCount": 4,
            "timeLong": "0",
            "partName": "第一部分",
            "quesScore": "5.0",
            "data": [
               {    
                    "mes":[
                            {
                            "value": "In Tom's class, every student __1__ a pen pal. His teacher, Miss White, __2__ them to send __3__ once a week. Tom knows his pen pal goes to school __4__ taxi. And his pen pal's mother is a nurse. His pen pal's father is a doctor. They live in front __5__ the car factory.",
                            "type": "_str"
                            }
                            ],
                    "type": "完形填空／阅读理解",
                    "count": "2",
                    "timelong": null,
                    "score": "2.0",
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 8,
                            "timeLong": 0,
                            "questionID": 4,
                            "score": null,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. me",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. my",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. I",
                                        "type": "_str"
                                    }
                                ]
                            ],
                            "vedioUrl": null
                        },
                        {
                            "content": [
                                {
                                    "value": "2.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 9,
                            "timeLong": 0,
                            "questionID": 5,
                            "score": null,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. with",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. at",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. to",
                                        "type": "_str"
                                    }
                                ]
                            ],
                            "vedioUrl": null
                        }
                    ],
                    "type": null
                }
    ],
    "totalScore": "21.0",
    "paperName": "LEVEL2通关考试",
    "totalCount": 13,
    "totalTimeLong": "01:00:00"
}
return _table
end
