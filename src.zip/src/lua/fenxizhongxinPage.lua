--分析中心/知识点排名
local fxzxPage = class("fxzxPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
fxzxPage.__index = fxzxPage
fxzxPage._uilayer = nil
function fxzxPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function fxzxPage:onEnter()
   
end

function fxzxPage:onExit()
end

function fxzxPage.create()
    local scene = fxzxPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function fxzxPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("fenxizhongxinSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    self:initList()
    return self._uilayer
end
function fxzxPage:initButton()
    -- body
print('title----'.._title)
    local ButtonBack=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
   ButtonBack:addClickEventListener(function() 
    require 'control' goUI(_SceneInfo_old)
--     if _title=='知识点排名' then  
--         print('知识点排名')
--         goUI(_allUI.fenxizhongxinPage) 
-- return
--          end
--     if _title=="分析中心"  then  print('分析中心') 
--      goUI(_allUI.mainPage)
--      return
--       end
   end)--返回主页
   local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
   _name:setString(_title)
end
function fxzxPage:initList()--初始化list列表
    -- body

    -- local _img_zsd=self._uilayer:getChildByName('Image_zsd')
     -- if _title=='分析中心' then _img_zsd:setVisible(false) end
    local _listView=self._uilayer:getChildByName('ListView')
    local _node=self._uilayer:getChildByName('item_node')
    local _item=_node:getChildByName('item_node')
    for i = 1, #_analysisCenter do
        local _temp=_analysisCenter[i]
        local paperscorerank=_temp['paperscorerank']
        local papertype=_temp['papertype']
        local examlevel=_temp['examlevel']
        local paperScore=_temp['paperscore']
        local papername=_temp['papername']
         local _items = _item:clone();
         local _name=_items:getChildByName('name')
         _name:setString(papername)
         local _score=_items:getChildByName('score')
         _score:setString(paperScore)
         local _rank=_items:getChildByName('rank')
         _rank:setString(paperscorerank)
            local _rank=_items:getChildByName('rank')
            -- local _button_rank=_items:getChildByName('Button_rank'):addClickEventListener(function() require "control" goUI(_allUI.zsdpaimingPage) end)
        _listView:pushBackCustomItem(_items);
    end
end
function fxzxPageCreate()
    return fxzxPage.create()
end



