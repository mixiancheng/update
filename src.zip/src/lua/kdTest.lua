-------------------------------------
-------------------------------------
--  StartGame Test
-------------------------------------
local kdTest = class("kdTest",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
kdTest.__index = kdTest
kdTest._uilayer = nil
function kdTest:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function kdTest:onEnter()
   
end

function kdTest:onExit()
end

function kdTest.create()
    local scene = kdTest.new()
    scene:addChild(scene:createLayer())
    return scene
end

function kdTest:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("kdTest.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    return self._uilayer
end
function kdTest:initButton()

    local _start=self._uilayer:getChildByName('Button_1')
    local _end=self._uilayer:getChildByName('Button_2')
    local _text=self._uilayer:getChildByName('Text_1')
     _start:addClickEventListener(function(...) 
    local _resulr=''
       local function progress( _per,_isLast)
            -- body
            -- print("_bool-------".._bool)
            print('lua-------play'.._per)
            _resulr=_resulr.._per
            if _isLast=="isLast" then 
            _text:setText(_resulr)
           end 
        end
       local args = {_fun=progress}
            local luaoc = require "cocos.cocos2d.luaoc"
            -- local luaoc = require "luaoc"
            local className = "RootViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"startListening",args)
            if not ok then
                print("The ret is:NO")
                -- Director:getInstance():resume()
            else
                print("The ret is:", ret)
            end
    end)
     _end:addClickEventListener(function ( ... )
       -- body
            local luaoc = require "cocos.cocos2d.luaoc"
            -- local luaoc = require "luaoc"
            local className = "RootViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"endListening",nil)
            if not ok then
                print("The ret is:NO")
                -- Director:getInstance():resume()
            else
                print("The ret is:", ret)
            end
     end)

end
function kdTestCreate()
    return kdTest.create()
end



