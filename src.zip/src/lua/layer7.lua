-- 此模块处理单选题
module("layer7",package.seeall)
local answer={}--选项答案
local answer_edit={}--填空答案
local _question_type=''--题目类型
local _question_id=''--题目id
local _question_timeLong=''--时长
local _question_serNo=''--
local _color=cc.c3b(90,38,12)
--layer 84  272
local _table_b=''--buttons
local _table_c=''--checks
function set_answer( _value )
  -- body
  for i,v in ipairs(answer) do
     if v==_value then  return end 
  end
  local _temp={}
  _temp['result']=_value
  table.insert(answer,_temp)
end
function sub_answer()--更新答案
  print('提交答案-------------')
  --body
  if _question_type==5 then --填空题 
  local _temp={}
    for i,v in ipairs(answer_edit) do
      local _item={}
      _item['result']=v:getText()
    table.insert(_temp,_item)
    end
  answer=_temp
  end 
  paperData.add_answer(answer)--添加答案
end
--创建复选框
local function creatCheckBox( _selectedEvent)
  -- body
    local checkBox = ccui.CheckBox:create()
    checkBox:setTouchEnabled(true)
    checkBox:loadTextures("cocosUi/ui/test/cs_yuanquan.png",
            "cocosUi/ui/test/cs_yuanquan.png",
            "cocosUi/ui/test/cs_dui.png",
            "cocosUi/ui/test/cocosUi/ui/test/cs_yuanquan.png",
            "cocosUi/ui/test/cs_yuanquan.png")
    checkBox:addEventListenerCheckBox(_selectedEvent)  --注册事件
    return checkBox
end
--创建填空
local function creatEditBox(_len)
    local arr =ccui.EditBox:create(cc.size(_len*18,30),"green_edit.png") 
    arr:setFontSize(30)
    arr:setFontColor(cc.c3b(0,0,0))
    arr:setMaxLength(_len)
    arr:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
    arr:registerScriptEditBoxHandler(function(strEventName,sender)
    if strEventName == "began" then
       sender:selectedAll()--光标进入，选中全部内容
       elseif strEventName == "ended" then-- 当编辑框失去焦点并且键盘消失的时候被调用
       sub_answer()
       elseif strEventName == "return" then-- 当用户点击编辑框的键盘以外的区域，或者键盘的Return按钮被点击时所调用
       sub_answer()
       elseif strEventName == "changed" then-- 输入内容改变时调用
       end
       end)
    return arr
end
--富文本
function RichText(_tables,size,_CheckBox)
    local richText = ccui.RichText:create()
    richText:ignoreContentAdaptWithSize(false)
    richText:setContentSize(cc.size(600, 70))
    for i,v in ipairs(_tables) do
   local _temp=v
   if v.type=='_str' and v.value~=nil and v.value~='' then --文字
    print('string-----------'..v.value)
    local re1 = ccui.RichElementText:create( 1, _color, 255, v['value'], 'Helvetica', size )
    richText:pushBackElement(re1)
   end
   if v.type=='_img' and v.value~=nil then --图片
    local _img=get_img_sprite(v['value'])
    local recustom = ccui.RichElementCustomNode:create( 1, cc.c3b(0, 0, 0), 255, _img ) 
    richText:pushBackElement(recustom)
    end
    if v.type=='_edit' then
    local len=v['value']
    -- local arr =ccui.EditBox:create(cc.size(len*18,30), ccui.Scale9Sprite:create("green_edit.png"))
    local arr =creatEditBox(len)
    table.insert(answer_edit,arr)
    local recustom = ccui.RichElementCustomNode:create( 1, cc.c3b(0, 0, 0), 255, arr ) 
    richText:pushBackElement(recustom)
    end
    end
    if _CheckBox~=nil then  
      local kong = ccui.RichElementText:create( 1, cc.c3b(0, 0, 0), 255, '      ' , 'Helvetica', 40 )
      richText:pushBackElement(kong)
      local recustom = ccui.RichElementCustomNode:create( 1, cc.c3b(0, 0, 0), 255, _CheckBox ) 
      richText:pushBackElement(recustom)
    end
    richText:setLocalZOrder(10)
    return richText
end
--答案记录
function add_old_answer(_question)--补充答案
  -- body
  local _old_answer=_question['user_answer']--旧答案
  if _old_answer==nil or _old_answer=='' then  return end 
  if _question_type==5 then 
    answer=_old_answer
    for i,v in ipairs(answer) do
          answer_edit[i]:setText(v['result'])
    end
  else
    for i,v in ipairs(_old_answer) do
      _table_c[v['result']]:setSelected(true);
    end    
    answer=_old_answer--确定答案 
  end            
end
--创建页面
function getLayer(_question,mes)
    -- body
    _table_c={}
    _table_b={}
    answer_edit={}
    answer={}
    _table_content=_question['content']
    _table_item=_question['option']
    _question_type=_question['type']
    _question_id=_question['questionID']
    _question_timeLong=_question['timeLong']
    _question_serNo=_question['serNo']
    print('type=='.._question_type..':questionID=='.._question_id..":timeLong==".._question_timeLong..":serNo==".._question_serNo)
    local _layer=cc.CSLoader:createNode("Layer_7.csb")
    _layer:setPosition(84,272)--设置位置
    local _listView=_layer:getChildByName('ListView')
    local _item_node=_layer:getChildByName('item_node')
    local _item=_item_node:getChildByName('item_node')
    --------------------------------添加题干----------------------------
    local _ScrollView=_layer:getChildByName('ScrollView')
    local _Panel=_ScrollView:getChildByName('Panel')
    
    -- local _tg=_layer:getChildByName("Panel_question")
    -- local _tg_text=RichText(_table_content,30,nil)
    -- _tg_text:setAnchorPoint(cc.p(0,0))
    -- _tg_text:setPosition(20,75)
    -- _tg:addChild(_tg_text)

    ---------------------------------添加选项-----------------------------------
    -- if _question_type==5 then  _table_item={} end --填空题
    -- print("_table_item-----len=="..#_table_item)
    -- for i,v in ipairs(_table_item)do
    --    local _items=_item:clone()
    --    local _CheckBox=creatCheckBox(function (sender,eventType )
    --      -- body
    --      for i,v in ipairs(_table_c) do
    --            _table_c[i]:setSelected(false)
    --         end
    --         _table_c[i]:setSelected(true);
    --         set_answer(i)
    --         sub_answer()--提交答案
    --    end)
    --    _CheckBox:setSelected(false)
    --    table.insert(_table_c,_CheckBox)
    --    local _text=RichText(v,25,_CheckBox)
    --    _text:setAnchorPoint(cc.p(0,0))
    --    _text:setPosition(100,10)
    --    _items:addChild(_text)
    --      local _button=_items:getChildByName('Button')
    --      _button:addClickEventListener(function ( ... )
    --          -- body
    --         print('i==================='..i)
    --         for i,v in ipairs(_table_c) do
    --            _table_c[i]:setSelected(false)
    --         end
    --         _table_c[i]:setSelected(true);
    --         set_answer(i)--确定答案
    --         sub_answer()--提交答案
    --      end)
    --     _listView:pushBackCustomItem(_items);
    -- end
    -- add_old_answer(_question)
    return _layer
end