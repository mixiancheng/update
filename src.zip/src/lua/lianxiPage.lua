--练习
local lianxiPage = class("lianxiPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
lianxiPage.__index = lianxiPage
lianxiPage._uilayer = nil
function lianxiPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function lianxiPage:onEnter()
   
end

function lianxiPage:onExit()
end

function lianxiPage.create()
    local scene = lianxiPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function lianxiPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("lianxiSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    return self._uilayer
end
function lianxiPage:initButton()
    -- body
require "control" 
    local ButtonBack=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
   ButtonBack:addClickEventListener(function() goUI(_allUI.mainPage) end)--返回主页
   local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
   _name:setString(_title)
   self:initList()
end
function lianxiPage:initList()--初始化list列表
    -- body
    local _listView=self._uilayer:getChildByName('ListView')
    local _node=self._uilayer:getChildByName('item_node')
    local _item=_node:getChildByName('item_node')
    print('_paperDetail--->'..#_paperDetail)
    for i = 1, #_paperDetail do
        print('i-------'..i)

        local _temp=_paperDetail[i]
        local _knowledgepoint=_temp['knowledgepoint']
        if _knowledgepoint~=nil and _knowledgepoint~=''then 
        local _coursewareurl=_temp['coursewareurl']
        local _courseId=_temp['coursewareid']
        local _knowledgeId=_knowledgepoint[1]['knowLedgePointID']--知识点id
        local _questionType=_temp['papertype']
        local _userLevel=_temp['examlevel']
        local _examcode=_temp['examcode']
        local _studentId=_temp['studentid']
        -- local _knowLedgePointID=
        local _items = _item:clone();
        if _knowledgepoint~=nil then 
           for k=1,#_knowledgepoint do
            local v=_knowledgepoint[k]
           local _text=_items:getChildByName('Text_'..k)
           _text:setString(v['knowLedgePointName'])
           _text:setVisible(true)
           end
        end 
         local _button_kj=_items:getChildByName('Button_kj')
         _button_kj:addClickEventListener(function ( ... )
             -- body
             print('播放课件'.._coursewareurl)
         end)
         local _button_lx=_items:getChildByName('Button_lx')
         _button_lx:addClickEventListener(function ( ... )
             -- body
             print('开始练习'.._courseId)
             kaoshi(_examcode,_studentId,function ( code,data )
                 -- body
                 if code==200 then require "control" goUI(_allUI.myLianXiPage) end
             end)
             -- get_questionList(_questionType,_userLevel,_courseId,_knowledgeId,function ( code,data )
             --     -- body
             --     print('get_questionList-------'..data)
             --     if code==200 then require "control" goUI(_allUI.testPage) end
             -- end )
             
         end)
        _listView:pushBackCustomItem(_items);
       end 
        
    end
end
function lianxiPageCreate()
    return lianxiPage.create()
end



