{
    "paperParts": [
        {
            "quesCount": 6,
            "timeLong": "0",
            "partName": "",
            "quesScore": "30.0",
            "data": [
                {
                    "count": "6",
                    "timelong": null,
                    "score": "30.0",
                    "type":"连线"
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1. Look",
                                    "type": "_str"
                                },
                                {
                                    "value": "2.see",
                                    "type": "_str"
                                },
                                {
                                    "value": "3.the bear.",
                                    "type": "_str"
                                }
                            ],
                            "mes":"请将单词与单词连线"
                            "serNo": 1,
                            "timeLong": 0,
                            "questionID": 3,
                            "score": null,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. at",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. on",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. for",
                                        "type": "_str"
                                    }
                                ]
                            ],
                            "vedioUrl": null
                        },
                    ],
                    "type": null
                }
            ],
        },
        }
    ],
    "totalScore": "47.0",
    "paperName": "LEVEL0通关考试",
    "totalCount": 23,
    "totalTimeLong": "60"
}

"answers": [
        {
            "answer": [
                {
                    "result": 1
                },
                {
                    "result": 3
                },
                {
                    "result": 2
                }
            ],
            "timeLong": "30",
            "questionType": 2,
            "questionID": 5
        }
    ]
