-------------------------------------
local lineSc = class("lineSc",function()
    return cc.Scene:create()
end)
lineSc.__index = lineSc
lineSc._uilayer = nil
local _answers={}--答案{"result":1}
for i=1,4 do
_answers[i]=''
end
local _startPoint=nil 
local _endPoint=nil
local size=nil
local _touchLayer=nil
local _curItem=nil
local _actionItem=nil
local _curLine=nil
local linesTable={} --a,b,line
local item_l={}
local item_r={}
local isLeft=nil
local function add_answer( _node1,_node2)
    -- body
    local _index,_value
    if _node1:getTag()>2000 then  
        _value=tonumber(_node1:getTag())-2000  
        _index=tonumber(_node2:getTag())-1000
    else
        _index=tonumber(_node1:getTag())-1000  
        _value=tonumber(_node2:getTag())-2000
    end
    local _temp={}
    _temp['result']=_value
    _answers[_index]=_temp
    local _mes=_answers[_index]['result']
    print('_index-----------'.._index)
    print('_mes-----------'.._mes)
end
local function add_line(_curItem,_actionItem)
    local _table_items={}
                 table.insert(_table_items,_curItem)
                 table.insert(_table_items,_actionItem)
                 table.insert(_table_items,_curLine)
                 table.insert(linesTable,_table_items)
                 add_answer(_curItem,_actionItem)
end 
local function dell_answer( _index )--清除答案缓存
    -- body
    local _item=linesTable[_index]
    local _index_l
    local _index1=_item[1]
    local _index2=_item[2]
    if _index1:getTag()<2000 then  _index_l=_index1:getTag()-1000 end 
    if _index2:getTag()<2000 then  _index_l=_index2:getTag()-1000 end 
    _answers[_index_l]=''
end
local function dellLine( _index )
    -- body
    local _drawNode_item=linesTable[_index][3]
    _drawNode_item:removeFromParentAndCleanup(true)
    dell_answer(_index)
    table.remove(linesTable,_index)
    print('tableLen-----'..#linesTable)
end
local function add_old_answer(  )
    -- body
    for i,v in ipairs(_answers) do
        if v~='' then 
        local _index_l=100+i
        local _index_r=200+tonumber(v['result'])
        local _node1=self._uilayer:getChildByName('FileNode_1'):getChildByName("Panel_"..'l_'.._index_l)
        local _node2=self._uilayer:getChildByName('FileNode_1'):getChildByName("Panel_"..'r_'.._index_r)
        add_line(_node1,_node2)
        end 
    end
end

function lineSc:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end
local function inside(_x,_y,_w,_h,px,py)--点和矩形判断
    -- body
    if px<_x or px>_x+_w or py<_y or py>_y+_h then  return false end 
    return true
end
local function insideNode(_node,px,py)--点是否在控件内
    -- body
    local _x,_y=_node:getPosition()
    local position = _touchLayer:convertToWorldSpace(cc.p(_x,_y))--世界坐标转换
    local _size=_node:getContentSize()
    local _bool=inside(position.x,position.y,_size.width,_size.height,math.ceil(px),math.ceil(py))
    if _bool~=true then return false  end 

    for i,v in ipairs(linesTable) do
        for j=1,2 do
          local _temp=v[j]
          if _node:getTag()==_temp:getTag() then 
            dellLine(i)
           _bool=false
           break 
          end 
          end  
    end
    return _bool
end
-- local function insideNode(_node,px,py)--点是否在控件内
--     -- body
--     local _x,_y=_node:getPosition()
--     local position = _touchLayer:convertToWorldSpace(cc.p(_x,_y))--世界坐标转换
--     local _size=_node:getContentSize()
--     local _bool=inside(position.x,position.y,_size.width,_size.height,math.ceil(px),math.ceil(py))
--     if _bool~=true then return false  end 

--     for i,v in ipairs(linesTable) do
--         for j=1,2 do
--           local _temp=v[j]
--           if _node:getTag()==_temp:getTag() then 
--             dellLine(i)
--            _bool=false
--            break 
--           end 
--           end  
--     end
--     return _bool
-- end
function getPointNode(px,py,_left)--获取触摸元素
    -- body
    if _left==nil then 
    for i,v in ipairs(item_l) do
       if insideNode(v,px,py) then 
       isLeft=true
       return v end
    end
    for i,v in ipairs(item_r) do
        if insideNode(v,px,py) then 
        isLeft=false
        return v end 
    end
    end
    if _left==true then 
        for i,v in ipairs(item_r) do
        if insideNode(v,px,py) then 
        isLeft=false
        return v end 
    end
    else
        for i,v in ipairs(item_l) do
       if insideNode(v,px,py) then 
       isLeft=true
       return v end
    end
    end 
    return nil
end
local function myLine( _drawNode,p1,p2 )
    -- body
    local color = cc.c4f(1,1,1,1)
    _drawNode:clear()
    _drawNode:drawLine( p1, p2, color)
end
function RichText()
    return richText
end
function lineSc:onEnter()
   
end

function lineSc:onExit()
end

function lineSc.create()
    local scene = lineSc.new()
    scene:addChild(scene:createLayer())
    return scene
end
function lineSc:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("test.csb")
    self._uilayer:setPosition(cc.p(0,0))
    _touchLayer=self._uilayer:getChildByName('FileNode_1')
    for i=1,4 do
    local _templ=self._uilayer:getChildByName('FileNode_1'):getChildByName("Panel_"..'l_'..i)
    local _tempr=self._uilayer:getChildByName('FileNode_1'):getChildByName("Panel_"..'r_'..i)
    table.insert(item_l,_tempr)
    table.insert(item_r,_templ)
    print('tag----'.._templ:getTag())
    size=_touchLayer:getContentSize()
    end
        local function onTouchBegan(touch, event)
            local location = touch:getLocation()
            print("onTouchBegan: %0.2f, %0.2f", location.x, location.y)
            _curItem=getPointNode(location.x,location.y,nil)
            if _curItem~=nil then _startPoint=cc.p(math.ceil(location.x),math.ceil(location.y)) 
            _curLine=cc.DrawNode:create()
            _curLine:setContentSize(cc.size(size.width, size.height))
            self._uilayer:addChild(_curLine,-10)
            else
                print('_curItem-------nil')
            end
            return true
        end
        local function onTouchMoved(touch, event)
            local location = touch:getLocation()
            local x=math.ceil(location.x)
            local y=math.ceil(location.y)
            _endPoint=cc.p(x,y)
            if _curItem~=nil then 
            myLine(_curLine,_startPoint,_endPoint)
            end 
            print("onTouchMoved: %0.2f, %0.2f", location.x, location.y)
        end

        local function onTouchEnded(touch, event)
            local location = touch:getLocation()
            local x=math.ceil(location.x)
            local y=math.ceil(location.y)
            _endPoint=cc.p(x,y)
            _actionItem=getPointNode(x,y,isLeft)
            if _actionItem==nil or _curItem==nil then 
                if _curLine~=nil then 
                _curLine:clear()
                _curLine:removeFromParentAndCleanup(true)
               end
            else
                 add_line(_curItem,_actionItem)
                 -- add_answer(_curItem,_actionItem)
            end  
            _curItem=nil 
            _startPoint=nil
            _endPoint=nil
            _curLine=nil
            isLeft=nil
            _actionItem=nil
            print("onTouchEnded: %0.2f, %0.2f", location.x, location.y)
            
        end

        local listener = cc.EventListenerTouchOneByOne:create()
        listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
        listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
        listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
        local eventDispatcher = _touchLayer:getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(listener, _touchLayer)
    return self._uilayer
end
function lineScCreate()
    return lineSc.create()
end



