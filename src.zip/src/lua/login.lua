-------------------------------------
-------------------------------------
--  StartGame Test
-------------------------------------
local loginPage = class("loginPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
loginPage.__index = loginPage
loginPage._uilayer = nil
function loginPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function loginPage:onEnter()
   
end

function loginPage:onExit()
end

function loginPage.create()
    local scene = loginPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function loginPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("loginSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    return self._uilayer
end
function loginPage:initButton()

    local _login=self._uilayer:getChildByName('Button_login')
     _login:addClickEventListener(function() 
       --  local function _ocBack()
       --      -- body
       --      print('lua-------play'.._per)
       --  end
       --  local function progress( _per )
       --      -- body
       --      print('lua-------play'.._per)
       --  end
            
        -- if 1==1 then return end 
    local _userName=self._uilayer:getChildByName('userName'):getString()
    local _passWord=self._uilayer:getChildByName('passWord'):getString()
if _userName=='' or _userName==nil then 
_userName='15801554991'
_passWord='2620187ss'
end
     login(_userName,_passWord,function ( code,data )
         -- body
         if code==200  then  require "control" goUI(_allUI.mainPage) end

     end)
    -- 
    end)
end
function loginPageCreate()
    return loginPage.create()
end



