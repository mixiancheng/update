-------------------------------------
--  StartGame Test
-------------------------------------
local logoPage = class("logoPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
logoPage.__index = logoPage
logoPage._uilayer = nil
function logoPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end
function RichText1()
    local richText = ccui.RichText:create()
    richText:setContentSize(cc.size(600, 1500))
    richText.width=600
    richText.height=1500
    richText:ignoreContentAdaptWithSize(false)

 
    local re1 = ccui.RichElementText:create( 1, cc.c3b(0, 0, 0), 255, '1.听录音，回答1-5题。选出所听到的单词或短语，每个单词或短语读两遍。 {W: Hi, Peter! Who is that boy in green? M: He is the new student in our class. His name is Oliver. W: What does he look like? M: He is taller than me. But I am fatter than him. W: Do you know anything more about Him? M: Yes, He comes from Canada. Both of his parents are teachers.}这部分显示在前端界面中，仅供前端语音合成。' , 'Helvetica', 20 )
    -- local re2 = ccui.RichElementText:create( 2, cc.c3b(255, 255,   0), 255, 'And this is yellow.' , 'Helvetica', 40)
    -- local re3 = ccui.RichElementText:create( 3, cc.c3b(0,   0, 255), 255, 'This one is blue.' , 'Helvetica', 40 )
    -- local re4 = ccui.RichElementText:create( 4, cc.c3b(0, 255,   0), 255, 'And green. ', 'Helvetica', 40 )
    -- local re5 = ccui.RichElementText:create( 5, cc.c3b(255,  0,   0), 255, 'Last one is red' , 'Helvetica', 40 )
 
    -- local reimg = ccui.RichElementImage:create( 6, cc.c3b(255, 255, 255), 255,'cocosUi/ui/login/dl_dengluanniu.png' )
 
    -- local re6 = ccui.RichElementText:create( 7, cc.c3b(255, 127,   0), 255, 'Have fun!!' , 'Helvetica', 40 )
    -- local arr =  ccui.TextField:create("input words here", "Helvetica", 30);
    -- arr:setTextColor(cc.c3b(0,0,0))
    -- arr:setMaxLengthEnabled(true)
    -- arr:setMaxLength(3)
    -- local arr =ccui.EditBox:create(cc.size(400,40), cc.Scale9Sprite:create("green_edit.png")) 
    -- arr:setFontSize(40)
    -- arr:setFontColor(cc.c3b(0,0,0))
    -- arr:setMaxLength(8)
    -- arr:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
    --响应事件函数

-- local function selectedEvent(sender,eventType)

--     if eventType == ccui.CheckBoxEventType.selected then

--         cclog("eventType == ccui.CheckBoxEventType.selected  ")

--     elseif eventType == ccui.CheckBoxEventType.unselected then

--         cclog("ccui.CheckBoxEventType.unselected  unselected  ")

--      end

--  end   

-- --创建复选框         

-- local checkBox = ccui.CheckBox:create()

-- checkBox:setTouchEnabled(true)

-- checkBox:loadTextures("cocosUi/ui/test/cs_yuanquan2.png",

--             "cocosUi/ui/test/cs_yuanquan2.png",

--             "cocosUi/ui/test/cs_dui2.png",

--             "cocosUi/ui/test/cocosUi/ui/test/cs_yuanquan2.png",

--             "cocosUi/ui/test/cs_yuanquan2.png")
--     local recustom = ccui.RichElementCustomNode:create( 1, cc.c3b(0, 0, 0), 255, checkBox ) 

    -- richText:pushBackElement(re1)
    -- richText:insertElement(re2, 1)
    -- richText:pushBackElement(re3)
    -- richText:pushBackElement(re4)
    -- richText:pushBackElement(re5)
    -- richText:insertElement(reimg, 2)
    -- richText:pushBackElement(recustom)
    -- richText:pushBackElement(re6)
 
    richText:setLocalZOrder(10)
 
    return richText
end
function logoPage:onEnter()
   
end

function logoPage:onExit()
end

function logoPage.create()
    local scene = logoPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function logoPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("logoSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    local function nextScene(node)
        local  pDirector = cc.Director:getInstance()
        print('------------------')
        -- UserDefault:getInstance():setStringForKey(this->keyOfDownloadedVersion().c_str(), "");
        --         UserDefault::getInstance()->flush();
        require "control"
        -- if true or _token=='' then goUI(_allUI.loginPage) return end
        if true or _token=='' or _token==nil then goUI(_allUI.loginPage) return end
        goUI(_allUI.mainPage)

    end
    -- require "img"
    -- local _test=get_img_sprite('')
    -- _test:setPosition(200,200)
    -- self._uilayer:addChild(_test)
    -- local _test1=get_img_sprite('')
    -- _test1:setPosition(200,500)
    -- self._uilayer:addChild(RichText1())
    self._uilayer:runAction( cc.Sequence:create(cc.DelayTime:create(2),cc.CallFunc:create(nextScene)))
    return self._uilayer
end
function logoPage:initButton()
local listView = self._uilayer:getChildByName("ListView"); --这是主界面中的Listveiew
self.item_node = self._uilayer:getChildByName("item_node"); -- 这里是一个做好的item项
self.item_node1 = self.item_node:getChildByName("Panel"); -- 这里是一个做好
self._item={}
   for i = 1, 10 do
    print('--------------------------')
        self._item[i] = self.item_node1:clone();
        listView:pushBackCustomItem(self._item[i]);
    end
end
function logoPageCreate()
    return logoPage.create()
end



