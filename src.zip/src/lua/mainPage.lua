-------------------------------------
-------------------------------------
--  StartGame Test
-------------------------------------
local mainPage = class("mainPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
mainPage.__index = mainPage
mainPage._uilayer = nil
local _login_out=nil
-- function RichText()
--     local richText = ccui.RichText:create()
--     richText:ignoreContentAdaptWithSize(false)
--     richText:setContentSize(cc.size(600, 600))
 
--     local re1 = ccui.RichElementText:create( 1, cc.c3b(255, 255, 255), 255, 'This color is white.' , 'Helvetica', 40 )
--     local re2 = ccui.RichElementText:create( 2, cc.c3b(255, 255,   0), 255, 'And this is yellow.' , 'Helvetica', 40)
--     local re3 = ccui.RichElementText:create( 3, cc.c3b(0,   0, 255), 255, 'This one is blue.' , 'Helvetica', 40 )
--     local re4 = ccui.RichElementText:create( 4, cc.c3b(0, 255,   0), 255, 'And green. ', 'Helvetica', 40 )
--     local re5 = ccui.RichElementText:create( 5, cc.c3b(255,  0,   0), 255, 'Last one is red' , 'Helvetica', 40 )
 
--     local reimg = ccui.RichElementImage:create( 6, cc.c3b(255, 255, 255), 255,'cocosUi/ui/login/dl_dengluanniu.png' )
 
--     local re6 = ccui.RichElementText:create( 7, cc.c3b(255, 127,   0), 255, 'Have fun!!' , 'Helvetica', 40 )
--     richText:pushBackElement(re1)
--     richText:insertElement(re2, 1)
--     richText:pushBackElement(re3)
--     richText:pushBackElement(re4)
--     richText:pushBackElement(re5)
--     richText:insertElement(reimg, 2)
--     -- richText:pushBackElement(recustom)
--     richText:pushBackElement(re6)
 
--     richText:setLocalZOrder(10)
 
--     return richText
-- end
function mainPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function mainPage:onEnter()
   
end

function mainPage:onExit()
end

function mainPage.create()
    local scene = mainPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function mainPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("MainScene.csb")
    self._uilayer:setPosition(cc.p(0,0))
    _login_out=self._uilayer:getChildByName('FileNode_out')
    -- self._uilayer:addChild(_richText)
    local function nextScene(node)
        local  pDirector = cc.Director:getInstance()
        print('------------------')
    end
    self:initButton()
    return self._uilayer
end
function mainPage:initButton()
    -- Button_wodecuoti
    -- Button_ceshi
    -- Button_jilu
    -- Button_zhishizhangjie
    -- Button_fenxizhongxin
    -- Button_yicuoti
    -- Button_lianxi
    -- Button_center
    -- Button_loginOut
--------------------------------错题
local Button_wodecuoti=self._uilayer:getChildByName('Button_wodecuoti')
Button_wodecuoti:addClickEventListener(function() 
    get_cuotiList(function ( code,data )
        -- body
        if code==200 then  require "control" goUI(_allUI.wodecuotiPage)  end 
    end)
end)
--------------------------------错题
--------------------------------测试
local Button_ceshi=self._uilayer:getChildByName('Button_ceshi')
Button_ceshi:addClickEventListener(function() 
get_testList('3','',function ( code ,data )
        -- body
        if code ==200 then require "control" goUI(_allUI.testListPage) end
    end)
 end)--测试
-------------------------------测试
local Button_jilu=self._uilayer:getChildByName('Button_jilu')
Button_jilu:addClickEventListener(function() 
get_myRecord(function ( code ,data)
    -- body
    if code==200 then  require "control" goUI(_allUI.recordPage) end 
end)
end)--记录
-------------------知识章节
local Button_zhishizhangjie=self._uilayer:getChildByName('Button_zhishizhangjie')
Button_zhishizhangjie:addClickEventListener(function() 
    _paperType=2
     get_zhishidian(function (code , data)

     if code==200 then  require "control" goUI(_allUI.zhishidianPage)  end
     end)

end)--知识章节
-- local function showName( _name )
--     -- body
--     print(_name)
-- end
---------------------
--------------------------------------------课后作业
local Button_fenxizhongxin=self._uilayer:getChildByName('Button_kehouzuoye')
Button_fenxizhongxin:addClickEventListener(function() 
get_testList('2','',function ( code ,data )
        -- body
        if code ==200 then require "control" goUI(_allUI.kehouzuoyePage) end
    end)
 end)--课后作业
--------------------------------------------课后作业
local Button_yicuoti=self._uilayer:getChildByName('Button_yicuoti')
-- Button_yicuoti:addClickEventListener(function() require "control" goUI(_allUI.yicuotiPage) end)--易错题
-------------------------练习
local Button_lianxi=self._uilayer:getChildByName('Button_lianxi')
Button_lianxi:addClickEventListener(function() 
get_testList('1','',function ( code ,data )
        -- body
        print('data'..data)
        require "control" goUI(_allUI.lianxiPage)
    end)
end)--练习
---------------------我的课表
local Button_center=self._uilayer:getChildByName('Button_center')
Button_center:addClickEventListener(function() 
    get_kebiao_date(function ( code,data )
        -- body
        if code==200 then  require "control" goUI(_allUI.selfInfoPage)  end
    end)

end)--个人中心
-----------------------
local _login_out_no=_login_out:getChildByName('Button_no')
_login_out_no:addClickEventListener(function ( ... )
    -- body
    _login_out:setVisible(false)
end)
local _login_out_yes=_login_out:getChildByName('Button_yes')
_login_out_yes:addClickEventListener(function ( ... )
    -- body
    login_out_data()
end)
local Button_loginOut=self._uilayer:getChildByName('Button_loginOut')
Button_loginOut:addClickEventListener(function() 
_login_out:setVisible(true)
  end)--退出登录
end
function mainPageCreate()
    return mainPage.create()
end



