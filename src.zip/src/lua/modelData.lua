_modelData=json.decode({
    "requestSystemName": "Ios客户端",
    "requestSystemID": "1",
    "requestSystemDate": "2017-07-30 10:07:45",
    "requestSystemTime": "10:07:45",
    "returnCode": "0000",
    "returnMessage": "执行成功",
    "paperParts": [
        {
            "quesCount": 5,
            "timeLong": "0",
            "partName": "听力一",
            "quesScore": "10.0",
            "data": [
                {
                    "desc": [
                        {
                            "value": "W: Hi, Peter! Who is that boy in green? ",
                            "type": "_voice",
                            "role": "W"
                        },
                        {
                            "value": "He is the new student in our class. His name is Oliver.",
                            "type": "_voice",
                            "role": "M"
                        },
                        {
                            "value": "What does he look like? ",
                            "type": "_voice",
                            "role": "W"
                        },
                        {
                            "value": "He is taller than me. But I am fatter than him.",
                            "type": "_voice",
                            "role": "M"
                        }
                    ],
                    "questionMes": "1.听录音，回答1-5题。选出所听到的单词或短语，每个单词或短语读两遍。",
                    "count": "5",
                    "score": "10.0",
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 1,
                            "timeLong": 0,
                            "questionID": 3499,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. Thursday",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. Tuesday",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. Friday",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "2.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 2,
                            "timeLong": 0,
                            "questionID": 3500,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. sing",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. song",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. young",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "3.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 3,
                            "timeLong": 0,
                            "questionID": 3501,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. play football",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. play basketball",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. play ping-pong",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "4.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 4,
                            "timeLong": 0,
                            "questionID": 3502,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. house",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. mouse",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. hot",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "5.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 5,
                            "timeLong": 0,
                            "questionID": 3503,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. read a book",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. read books",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. watch TV",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        }
                    ]
                }
            ],
            "type": "compQues"
        },
        {
            "quesCount": 5,
            "timeLong": "0",
            "partName": "听力二",
            "quesScore": "10.0",
            "data": [
                {
                    "desc": [
                        {
                            "value": "Jim likes eating candy very much. His parents often tell him not to eat too much candy, so he always takes candy to school instead of eating at home. One day Jim came back from school with a terrible look. And he even can't speak with his mouth opening. He can just say some words like a snake. Jim's mother was surprised at Jim's words. And She found that Jim's teeth was all black so she took Jim to see the dentist.",
                            "type": "_voice",
                            "role": "M/W"
                        }
                    ],
                    "questionMes": "2.听录音，回答6-10题。选出所听到的单词或短语，每个单词或短语读两遍。",
                    "count": "5",
                    "score": "10.0",
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 2,
                            "timeLong": 0,
                            "questionID": 3507,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. Yes, I am.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. Yes, I do.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. No, she doesn't.",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "2.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 3,
                            "timeLong": 0,
                            "questionID": 3508,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. She is our new Chinese teacher.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. She is young and strict.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. She is Miss Li.",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "3.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 4,
                            "timeLong": 0,
                            "questionID": 3509,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. His favourite drink is tea.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. His favourite food is chicken.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. He'd like some tea.",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "4.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 5,
                            "timeLong": 0,
                            "questionID": 3510,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. I can draw cartoons.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. No, but I can draw cartoons.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. Yes, I can.",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "5.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 6,
                            "timeLong": 0,
                            "questionID": 3511,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. Yes, it is.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. Yes, there are.",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. Yes, they are.",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        }
                    ]
                }
            ],
            "type": "singleTypeQues"
        },
        {
            "quesCount": 5,
            "timeLong": "0",
            "partName": "单项选择题",
            "quesScore": "15.0",
            "data": [
                {
                    "count": "5",
                    "score": "15.0",
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1. I’m lost Can you help ____?",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 3,
                            "timeLong": 0,
                            "questionID": 3512,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. me",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. mine",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. I",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "D. my",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "2. If you want to send a letter, you can go to the ____.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 4,
                            "timeLong": 0,
                            "questionID": 3514,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. post office",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. park",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. school",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "D. restaurant",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "3. How ____ she come to school?",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 5,
                            "timeLong": 0,
                            "questionID": 3515,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. does",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. is",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. do",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "D. are",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "4. ____ go to the park!",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 6,
                            "timeLong": 0,
                            "questionID": 3516,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. Let’s",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. Let",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. Lets",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "D. Lets’",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "5. It’s next ____ the cinema. Just over ther.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 7,
                            "timeLong": 0,
                            "questionID": 3513,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. to",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. for",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. on",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "D. at",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        }
                    ]
                }
            ],
            "type": "singleTypeQues"
        },
        {
            "quesCount": 4,
            "timeLong": "0",
            "partName": "填空题",
            "quesScore": "20.0",
            "data": [
                {
                    "count": "4",
                    "score": "20.0",
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1. Can you ",
                                    "type": "_str"
                                },
                                {
                                    "value": 10,
                                    "type": "_edit"
                                },
                                {
                                    "value": "(游泳)?",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 8,
                            "timeLong": 0,
                            "questionID": 3520,
                            "type": 5,
                            "option": [
                                []
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "2. ",
                                    "type": "_str"
                                },
                                {
                                    "value": "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCABRAFEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD/AD/6KKKACiivo/4K/sx/EL43aT4m1nw7Zy2thpOh6pd6HqF1Eg0vxD4k0q90SGXwmuoNPFDp2oz2WsfbIZrvEP7pFYCKSSeDKtXo4em6tepClTTSc5yUY3k1FK7a1ba0V3a7taMmvMzfOcqyDAVczznH4bLcvoSpQq4vF1Y0qMJVqtKhTTlJ3blUrQuoqTjTjVqyiqVCvOl84UV9VfHn9kH4q/ALS7DxLr9vb614R1TxBceGrHxDpMdx5Tanb6Np2sgXNpKhmtLa9S61C30yeRj9sk0HViyQeSiyfKtRhsVhsZSVfCV6WIpOUoe0pTU4qcGlODtrGcG0pRklKLautU28oznKs/y/D5rkuPw2ZZdiouVDF4SoqlGpaylG9oyhUg5KNSnUhTqU5PlnCMk0iiiiug9IKKKKAP8Af4ooooA/wB6K7bQPA994k8J+NfE+mXlpLP4H/sG81LQBvOrXPh7Vp9QstQ8SWcSgiXTfDmpRaJZ6yFDSwL4jsrwhbS2vJYux+CfwB+Jvx+8UW3hr4e+H572IXdrFrniS8/0Lwt4Usp3zPq3iPW59tnp9jZWqT304LvdSW1tO1tbzsm081XGYWhTxNatiKVGlg03ialWapwoJU41rzlPlSTpyUotcynflhzzvA4sVmOAwOHxOKxuMw2Dw2DaWKxGKrQw9Gg5RhKCnOtKnHmqKpTVGMPaSrznGlQhXrSjRfB+BPCN98QPGvhPwLpd5pthqnjHxFo/hjS7zWJ5LXSoNS12/g0ywfULqGC5ktrM3dzCs9wlvMYY2aQxsFIr+pPQ/hHpnwV8G6F4OsdKtPDeorZ6fqvi3T7aZLjRn8fXGh6Np3i+KC5gUW6WF1fabN5EkKPApleYFYpt6fk78KP2JfjV8EPi58K/jDc6B8N/Hfwyt/HcWqaNa+Mtc0aw/4Tz4bWut3mkXHjObwzdS3d7omk6pplre6todzcP/AGxYXEdle2lvJdw2/mfuN8VvEWi69r5j8NarFrNhqYFyup2c8V5ptxZXRZ4Q2QxlvSjJK+AktmX/AHqxzkAfk/Fuf/2hneTYHLcTSxWXLA4vG4udCpGahiIVaMVDFRVpUnSw1RVYUq8G3UnN03CpCtCn+EfTK4K8ROE+DeDMx4m4P4s4b4ZzvHrFZfmGc5Dm2WZdmuNp0/bYfCxxOJwtPDvGU8JUrYujl+KqYXMLKviKGDnGjjFS9Y+Dun291KIr7TbPVbW4vZZXt7+ztdS02Gwe0a3VZ0uo5reQz2t3d2z3P3ms/PjVwLmVa/A//grr+wzov7LvxB+H3xB+FHhXSvC3wN+Kmh2uheGtEtNcuNU1iz8feE9MsG8aRXljfyz6rHaagdU0zUtPvZJZILmS6u7WBYRZrHX7a/s5+HPiF418VeLNGvGuo9Z0zwX4uTwja+Gkv7rw34OXS7A6ra6xdpdS6THrHivxFLpcui6fquu3kemWV3dadp+h6HfnUJ0l9o+P3weuvBvgK4Hj+2+Gv7YPws03w7BrmgXnizQtG1T4ifAhvEuoeFNYk8a+HraPU9cli0TVBDpWnavpq3C61o9lY/bd2n2ceNQ/L8ozLOsh4uoZ7luIjjMsqVKuCzfJY1p4ZY7CVYyo0cRQniqkcE8Zl9aNLERqSoOUaH13D0pzrYqM1/XXhj9Anxe8NfCDKeNa/EfC+ecSZ3wVheO8P4TZBPMszzzMcnzTIYcUZThck4hwyrcJZpxLjspxmDq5bk0pZZPNMVi/7JynMMXmMsHRzH+aH9mH/glv8XPi9PbeKfi/O3wW+Gdh4g1vQtej1uGW3+Jd1daFbQvLFoXhG/tYwlpd39xHpq63qU8VpA8N7cRWt+tvHFcfSvir/gld8GdB06xj0j4reJ9a1rT/AA1cJfte2Nrp2ma/4tlu5ANVlltIr+fw/wCD9Lt/Khi0q3h1bXdTuI5mn1axW4jjtv021Hxz4n8ZNaywTvdSXEWqTwu06LFKxa0gsmNxMyxGNGukljZnWMxq2wZxnU0j4Ya5qRL3en6o4ZLa2ikutPcWaR2pWXzDbtcQ3Fz5k+93N0kFvINu1J1xX2eJ4v4ihinjs2zyhldFP93k+Xxw8aMIp2aqVsTGeKxM3afNWlOndcqhRhKKlP8AzQ4g+kP4gZ3j5UuFaDyilGbhChHALFYhOL5ZQr0sRQlOFRTjOlVWLlhJ05RnCdGjUp1FT/mD/aM/ZV1/9noWN5qPirQ/EGkarcR2ekTWyXNprGpvHaR3Go6gdHCXiaZpVnPNDZxyalqUN5czTRNHabXcRfKdf0E/8FbJIvhl8J/h38P5Y7e81b4i61e6zPMfEi6be6bpXhh7RoppfA9jPHPqVtqd9dPFa67q0c2lWMtne2tik2pyyT2X8+1frfCmcyz/ACXD5m2pxrVMRTp1opRjXhh60qDrRikuVSqQqR1SbcJSSUXE/rTwrzfinPeC8uzLjGjSpZ1Wq4uE5UqVCh7fC0aypYbEVMPh/wB1QrVYxqe1hBuLnFzioU5U6cP9/iiiivoz9FP8ET4XTeLI/iD4St/A94LLxRqut2OhaVJJHBPaTS67MukS2WpWl3HNZ3+k30F5Jaapp99BPZX1hNcW13BLBK8bf0Y+Gfhh4B8IfD7xT4W0CSz8LaJ4Zv4tf+JuneDxd2Gn6pevbae3iF9WsfN1PU9M0O5i+zaymi2l2bKHSbWPS1Eujefav/Nh4U1aXQfFHhvW4b6bTJdH17SNTj1K3VnnsHsNQt7pbyFEBeSS2MXnJGoLOyBQCTiv6YfC/wAffA/iTTPiBquj2msSeEvihr+j+L/CWvaWka6lYJpumXGmpd32nPqVvZxTX7www65oV2lyEtp7/TrsI0dsB+Y+I9TG06GEhhcJVrU8TCdOvWoc0HF069GUITmnySkqUq1WhGcJTpuNWpSlBrln9j4ReCme+LnjPwfnGB4qyThrLfCKWReKdLBcQ5Tgc6yDi7inh3j/AIcWVcM8S5djMRSq18kxeSPiFrG5fQx2N4ezGpgc7pYOvUoYWmfqb8AvjX8GPB3w80DWvFmueFNb8UC58UeGbzQ9Z0GaWO78I6lbyy6Za6ff6RYXmq3Gm+Ddf0PSdUttY/tXQfDdv4S8Y33g4RjT7W4e58p+Nfwg8C3V/F8bPh34c8Nyan4a1jw3bap8MPBmrJOfEknxM8P6jd23jPQfC1hrN3aaRrOkWVzZ21ppi3c+neKL3QtT0uWzs79GkT4H+FGtab/bgbxF4I/t7w4JbW2v7Tw9p2nvFottd209gZJdDisXvbzSFgEaPb2s1mJGgjnklurlUM3198Rfiz4BufhZJ4H+Dnhm3sj4gvdN8OeL/iTJpsmnW9rLDZnQ7Hwd4HluJItRFjofh5roXWrQRJcalql1qVx9qgt7iWa7/CMzq5ll1fLsHhsLiZuviacMVXjUoQoYfBpuWMnjKjqyrUqlWgnCiqLjWqYr2UsPCcZV5R/1K8YeOcw4h8RsB4b+GHhjivFivxLmPD2P8QXj8FwjxP4c5TwzmWPo4XG5DmFPMcVLAZLjMDh8xzxwx3EPDGFq4XLK0MXw1/a9XF1uT5q8GfFzx54R8V6n4n8JeIvEfhXxBO+rJcagmlva2eja1pctub220aXUp7IW8lxqOl3V6+l6rJc3egazczw6SizRRPbfXfwV/aP8Qax4z+HPgjxl4T0rxrpmrfEO1tj4r8V6T4416+tPCt5odhYR3B8H6ffXei6/Do+jRw62ftzSzz2mjtFvVbUXley/CL4Aab8UvgX4R0Dxh4um8G+CtYvPHmo6dc6Nqmm6jpc97Y6F4Zm0+48ZxXmkeIrTz7yRdZiuba6vo9Ta306wjuNPsrmGC8H5jeKfgH448J/Hyy+A2k3vh608ReM7pG8KeKtXvbPRfA974a1XTry/tvF9/qurNdadomk2ulSTXAgkkn1TS9SU6LbKNaWCM+3hKNHFWSUaaSVZQryjKMuX2bTfLrCbi4ezqSp+84+61VjzH9DZlR4ayDJ3wdkeFpxwvBWBw/CuXUsuo4p1cnyHK/ruVZcsNj8RUjia+U5DRVHByyqjmeYSybLsJlmBqKvhKEsZU+tvCMHwa+HfipvBt38VvBviLwPq+j+J/HXgjXI7garbabp+leMtR0HUPh/q08No/wBu12wgj0rWvCkdlBBq2oaJqi2t3pGm6paSWjfXnwW+J37OPiDxbZeH7+68X+E7WXTL/Wk8R6p4A14QXem6ZY3uoSS2OixvJ4juoJLewmYXMdh5FtAsl27FLeaNfn/wB4L+Fn7OcvhOT4r+LNOv/jVrfhnXviBcXms6Be+IvCWk+Dta0y9/sXQ/Csx0XxK3wu+IOqrZR6rBdeILUSXzeKG1K8OkrplnHq3q3xe/ay+HHxJ+GWs6tB4sisPiBpsGmaH4f05fDVnpUWmW9/Pp2seL/Ehe1ubqx07U/iTqEl2h8XaTPpsvhHwl4Ui8PzeG1l8RXk0XzmcZFhc0r1amNxWbvDqFBrC0MbLBUK0YxXtW6tKm8Rz14qEZQdGk4zd6EY05KVH+LcZ9AHwD458QuIuM3w5xbUzHxAzSeMzDEcO5jhMi4fyDiTHutSzDiLC5Vg+Gszq5nh82zhVs7zSeNzXC5VHEPNcRQwtKvm+JVT+UD/gpx8VP2gPif+0j4kf416W+heHvDup67p3wa0SzstNbw7p/w2udRN5oY0LxLpmlaani9LmwexutQ1u5ae6lv5pxLHYsWs4vhZPAnil/A8/xHOmCLwbB4ih8JrrFxe2Ft9s8QS2L6k+naZY3F1HqOqvZ2Sx3GpTadaXNvpaXVj/aEts19aiX+jX49/Bnw78Ufh9beFvFguPFktlJeeNvBOlR6raeHpY7pLG7u7Dw3pusJpV9fWfhfUbaeOG5SGwmvbSxmtoILiJLS0lg/nX8e+OdY8Z39nBeWdloOieG7ebSPDPg7Ro57fQfCunm4ea4s9Pt7ie5uZbu7vGku9X1bULm71bV793utRvJ3EQi/pbgnF0quQZRgcuwOGwFDL8LhqFanSh7PDwpU4Sivq9D2sqyr4ucJ161StKUKdapiqkquLrVo2/ydyTP8DiuIuOeCcqzTIs7qeGnHHEXBeM4hyCOJXD/ABHl2QZ1m2T5dxJw9SxNOhXWEz9ZTiaklfEYPL8fg81w+HxmZYZ5VisX/veUUUV9ufZn+APX9lH7Iuq/8EK/jR+yB8G/hZ4J8c+Gf2X/AI9+H/DOmTfFS++NnjnXPh/8R/EnxVk0q0i8ba3/AMLI1hdQ+EfjLwNqurW8174Q0NYtFGh6G1rYSaBpeqQ6hc3X8a9FcWPwNHMcO8NXlONNyUvccU7xvZtSjJOzd1tZ6pnq5NnWacP5hSzTJ8bicvx9BSVLFYSvVw9aEZpKcFOlKLlTqRSjUpVI1qNWHu1KNRJcv9oXiv8AZs/Za+FPgL4o+NfC/wC3x+zP4i13RvBPiO98L6P/AMLu+EOpa9rWqJYubLQtIt/D/iZJb7UdTCizso4dMublpPL8lUkJJ+IoPiBYp8N/Bng06PJFqXg3XbvWB5sW7T9ei17bJq0WotHeQTKLeOy0e0s4miSRo45ZFvYvMjth/M1X7Wf8Eq/An7Rv7dnxcP7MXw/g8Gapf+Gfh54r+Il/418eeJJ/D8PhjwZ4RisYrh9R+x2Orat4qMmo6lpGkWVho+l3WsxC+W+u5V0bTNQuLf8AOs/4Cw86UcVhJVa86LdStGpVjCpJU4TUJRv+6nGnCVROk/Zt83NTftG2/wCvvo+/SUlwjnmfPjLE0p43iPG5LjIcSY2jiayjWybL8TlGEwGYVcv9niMJgaWEx2KnhauGwv1WhXxWOrYihGviHjpfoN8NvjH4i8H6h4Z1PQtbu9WbQ7jSrq48L6jrt5Jo11bRwXV3d6JPokWpeGdWVbqWw05b6TRL6+uooYbW9truO9isQnvv7R7w+NPgZ8NvjbbTfD7wp4n8N+H9Rvfin8M9K1fU9J8Q+I/C/wARPHOk6F4aN9aeKtV/4SvWNO1gw2ninTpE09dMvfCEl3bx3dyNPu7q/wDmr4m/si/tIfB/UZrXxt8JtccWjyQyaz4MntfH+iKkJLLdWmoeG1uL2CEYRraW906yuWcpFLBGw2rufA39jL9r/wDbW1bWfhB8MPDsXg6PUtK1Wwf4lfFnR/EXhn4ereTE6loGgo9tpF3qg1B9Wt9P0+0svBmg3jQS3+oatr1zbWFq8rfBQySSxVGFKMZudanRXNFRqUoVJqNT2kvZy5KfJKUm4uKg6cW1a8n/AHDm3jTwhmWU4nimvxBk2Fp5bgcXjsdisFm2XY2hmkVhsby4DCUqGZ0sVi8VWqzwlHDUsXgp5jOdSnGjTSoylT8LvvHOvagNPm1ex0W9urHSNI0N4Utls420vRoj9nsrWTQotDNtbBmbYsQlK2UcWliWOygiiD5vF95qNzYnU47S4ghQRajLqsK+IhM188S3mpXFpfxM1yscUUAtNP8AOmiQ20dtHLEPMRfvf9maH/gkHqvwB0L9mf46/Eiz+Af7cPwRv/FPw8/aO1z43fF7xHoF74i+LXhjxDqeg+J9Q8BfFzTL/XfhDr/w9S7sRa+D9KY2F9plhEy3VtfSTSard9rP+xT+wxpZg1rXP+Cg/wAEdD8IbpCNUn/aR+AuoyzQebwWvEe4vnaMhlSQ6c8rYyqFgpP0GO4Tq0a06P1StVTdoVsPTxLjJNP34OSm43unu7KMUuXc/BMl+mLwvWy32GOljsFSq4fFYbE5ZmHD2Gx9KrhsdQlQxOGeIyrNaNNwhSqYihS5KOEqOniKiqzqS5fZ/AnxW+O/gTw54Qv/ABFY3DJfeAfg78TX0LxP43jEd3r/AMTdbla70KC6lmt4pop9Ygs4103SLa6lsZLhk0y2SOO3M1x/MdPPLczzXM7mSe4lknmkbG6SWV2kkc4AGWdixwAMngV/Q5/wV/8AGf8AwSfsvgd8MPg1+xz418c/Gb9o/wAK+PrjWPGvxe0DxT4k1T4QXPgu50m8tdR0PW7jxFaaRo/i7xSNZXS7nwnqXgLw5Y6RoOkDXLe813Vf7UtrWD+d6vv+DOHlkGArKVStOrjasK04VlrQjTjUjGnFu0mpupKrO8YRU+VQioRsfwn40cTcJ8deJmYcZ8K8P0sgwtfhnhThSOHo0MFg8NLA8I089p5esDluAwmDwmUYCEM+rwpZbh6MaVOdFYjlpVK8qFP/AH+KKKK+wPzI/wAAeiiigArufht8TfiL8HPG2gfEn4T+OvFnw2+IHha8+3+HfGfgjX9T8M+JdFu9jxPLp+saRc2l9bedBJJb3MaTCK5tpZra4SWCWSNuGoo30eqfR6oD9rvCf/BwV/wU48O21vBrvxT+HnxOuLYgpqvxN+CPwt8R63KqxmMC71a18NaVfX0hz5j3V7NPezSjzJ7mVixbzn4v/wDBcT/gpr8Y9C1LwrfftIap8O/DOsWF3pmqaP8ABXwx4T+Eb32n32VubKfXvBWj6Z4q+yyRFrdrePXo4HgeSOSNxI+78l6K5o4PCRn7SOFw8Z3vzqhSUr73vyb31v3NHWqtWdWo0lbWcnp2ve9vK9vUfJJJNJJNNI8ssrvJLLI7PJJI7FnkkdiWd3YlndiWZiSSSSaZRRXSZhRRRQB/v8UUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAf/9k=",
                                    "type": "_img"
                                },
                                {
                                    "value": " He often",
                                    "type": "_str"
                                },
                                {
                                    "value": 10,
                                    "type": "_edit"
                                },
                                {
                                    "value": "(做运动).",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 9,
                            "timeLong": 0,
                            "questionID": 3517,
                            "type": 5,
                            "option": [
                                []
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "3. Can you ",
                                    "type": "_str"
                                },
                                {
                                    "value": 10,
                                    "type": "_edit"
                                },
                                {
                                    "value": " ",
                                    "type": "_str"
                                },
                                {
                                    "value": 10,
                                    "type": "_edit"
                                },
                                {
                                    "value": "(打篮球)?",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 10,
                            "timeLong": 0,
                            "questionID": 3518,
                            "type": 5,
                            "option": [
                                []
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "4. I'd like a",
                                    "type": "_str"
                                },
                                {
                                    "value": 10,
                                    "type": "_edit"
                                },
                                {
                                    "value": "(汉堡). ",
                                    "type": "_str"
                                },
                                {
                                    "value": "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCABRAFEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD/AD/6KKKACiivo/4K/sx/EL43aT4m1nw7Zy2thpOh6pd6HqF1Eg0vxD4k0q90SGXwmuoNPFDp2oz2WsfbIZrvEP7pFYCKSSeDKtXo4em6tepClTTSc5yUY3k1FK7a1ba0V3a7taMmvMzfOcqyDAVczznH4bLcvoSpQq4vF1Y0qMJVqtKhTTlJ3blUrQuoqTjTjVqyiqVCvOl84UV9VfHn9kH4q/ALS7DxLr9vb614R1TxBceGrHxDpMdx5Tanb6Np2sgXNpKhmtLa9S61C30yeRj9sk0HViyQeSiyfKtRhsVhsZSVfCV6WIpOUoe0pTU4qcGlODtrGcG0pRklKLautU28oznKs/y/D5rkuPw2ZZdiouVDF4SoqlGpaylG9oyhUg5KNSnUhTqU5PlnCMk0iiiiug9IKKKKAP8Af4ooooA/wB6K7bQPA994k8J+NfE+mXlpLP4H/sG81LQBvOrXPh7Vp9QstQ8SWcSgiXTfDmpRaJZ6yFDSwL4jsrwhbS2vJYux+CfwB+Jvx+8UW3hr4e+H572IXdrFrniS8/0Lwt4Usp3zPq3iPW59tnp9jZWqT304LvdSW1tO1tbzsm081XGYWhTxNatiKVGlg03ialWapwoJU41rzlPlSTpyUotcynflhzzvA4sVmOAwOHxOKxuMw2Dw2DaWKxGKrQw9Gg5RhKCnOtKnHmqKpTVGMPaSrznGlQhXrSjRfB+BPCN98QPGvhPwLpd5pthqnjHxFo/hjS7zWJ5LXSoNS12/g0ywfULqGC5ktrM3dzCs9wlvMYY2aQxsFIr+pPQ/hHpnwV8G6F4OsdKtPDeorZ6fqvi3T7aZLjRn8fXGh6Np3i+KC5gUW6WF1fabN5EkKPApleYFYpt6fk78KP2JfjV8EPi58K/jDc6B8N/Hfwyt/HcWqaNa+Mtc0aw/4Tz4bWut3mkXHjObwzdS3d7omk6pplre6todzcP/AGxYXEdle2lvJdw2/mfuN8VvEWi69r5j8NarFrNhqYFyup2c8V5ptxZXRZ4Q2QxlvSjJK+AktmX/AHqxzkAfk/Fuf/2hneTYHLcTSxWXLA4vG4udCpGahiIVaMVDFRVpUnSw1RVYUq8G3UnN03CpCtCn+EfTK4K8ROE+DeDMx4m4P4s4b4ZzvHrFZfmGc5Dm2WZdmuNp0/bYfCxxOJwtPDvGU8JUrYujl+KqYXMLKviKGDnGjjFS9Y+Dun291KIr7TbPVbW4vZZXt7+ztdS02Gwe0a3VZ0uo5reQz2t3d2z3P3ms/PjVwLmVa/A//grr+wzov7LvxB+H3xB+FHhXSvC3wN+Kmh2uheGtEtNcuNU1iz8feE9MsG8aRXljfyz6rHaagdU0zUtPvZJZILmS6u7WBYRZrHX7a/s5+HPiF418VeLNGvGuo9Z0zwX4uTwja+Gkv7rw34OXS7A6ra6xdpdS6THrHivxFLpcui6fquu3kemWV3dadp+h6HfnUJ0l9o+P3weuvBvgK4Hj+2+Gv7YPws03w7BrmgXnizQtG1T4ifAhvEuoeFNYk8a+HraPU9cli0TVBDpWnavpq3C61o9lY/bd2n2ceNQ/L8ozLOsh4uoZ7luIjjMsqVKuCzfJY1p4ZY7CVYyo0cRQniqkcE8Zl9aNLERqSoOUaH13D0pzrYqM1/XXhj9Anxe8NfCDKeNa/EfC+ecSZ3wVheO8P4TZBPMszzzMcnzTIYcUZThck4hwyrcJZpxLjspxmDq5bk0pZZPNMVi/7JynMMXmMsHRzH+aH9mH/glv8XPi9PbeKfi/O3wW+Gdh4g1vQtej1uGW3+Jd1daFbQvLFoXhG/tYwlpd39xHpq63qU8VpA8N7cRWt+tvHFcfSvir/gld8GdB06xj0j4reJ9a1rT/AA1cJfte2Nrp2ma/4tlu5ANVlltIr+fw/wCD9Lt/Khi0q3h1bXdTuI5mn1axW4jjtv021Hxz4n8ZNaywTvdSXEWqTwu06LFKxa0gsmNxMyxGNGukljZnWMxq2wZxnU0j4Ya5qRL3en6o4ZLa2ikutPcWaR2pWXzDbtcQ3Fz5k+93N0kFvINu1J1xX2eJ4v4ihinjs2zyhldFP93k+Xxw8aMIp2aqVsTGeKxM3afNWlOndcqhRhKKlP8AzQ4g+kP4gZ3j5UuFaDyilGbhChHALFYhOL5ZQr0sRQlOFRTjOlVWLlhJ05RnCdGjUp1FT/mD/aM/ZV1/9noWN5qPirQ/EGkarcR2ekTWyXNprGpvHaR3Go6gdHCXiaZpVnPNDZxyalqUN5czTRNHabXcRfKdf0E/8FbJIvhl8J/h38P5Y7e81b4i61e6zPMfEi6be6bpXhh7RoppfA9jPHPqVtqd9dPFa67q0c2lWMtne2tik2pyyT2X8+1frfCmcyz/ACXD5m2pxrVMRTp1opRjXhh60qDrRikuVSqQqR1SbcJSSUXE/rTwrzfinPeC8uzLjGjSpZ1Wq4uE5UqVCh7fC0aypYbEVMPh/wB1QrVYxqe1hBuLnFzioU5U6cP9/iiiivoz9FP8ET4XTeLI/iD4St/A94LLxRqut2OhaVJJHBPaTS67MukS2WpWl3HNZ3+k30F5Jaapp99BPZX1hNcW13BLBK8bf0Y+Gfhh4B8IfD7xT4W0CSz8LaJ4Zv4tf+JuneDxd2Gn6pevbae3iF9WsfN1PU9M0O5i+zaymi2l2bKHSbWPS1Eujefav/Nh4U1aXQfFHhvW4b6bTJdH17SNTj1K3VnnsHsNQt7pbyFEBeSS2MXnJGoLOyBQCTiv6YfC/wAffA/iTTPiBquj2msSeEvihr+j+L/CWvaWka6lYJpumXGmpd32nPqVvZxTX7www65oV2lyEtp7/TrsI0dsB+Y+I9TG06GEhhcJVrU8TCdOvWoc0HF069GUITmnySkqUq1WhGcJTpuNWpSlBrln9j4ReCme+LnjPwfnGB4qyThrLfCKWReKdLBcQ5Tgc6yDi7inh3j/AIcWVcM8S5djMRSq18kxeSPiFrG5fQx2N4ezGpgc7pYOvUoYWmfqb8AvjX8GPB3w80DWvFmueFNb8UC58UeGbzQ9Z0GaWO78I6lbyy6Za6ff6RYXmq3Gm+Ddf0PSdUttY/tXQfDdv4S8Y33g4RjT7W4e58p+Nfwg8C3V/F8bPh34c8Nyan4a1jw3bap8MPBmrJOfEknxM8P6jd23jPQfC1hrN3aaRrOkWVzZ21ppi3c+neKL3QtT0uWzs79GkT4H+FGtab/bgbxF4I/t7w4JbW2v7Tw9p2nvFottd209gZJdDisXvbzSFgEaPb2s1mJGgjnklurlUM3198Rfiz4BufhZJ4H+Dnhm3sj4gvdN8OeL/iTJpsmnW9rLDZnQ7Hwd4HluJItRFjofh5roXWrQRJcalql1qVx9qgt7iWa7/CMzq5ll1fLsHhsLiZuviacMVXjUoQoYfBpuWMnjKjqyrUqlWgnCiqLjWqYr2UsPCcZV5R/1K8YeOcw4h8RsB4b+GHhjivFivxLmPD2P8QXj8FwjxP4c5TwzmWPo4XG5DmFPMcVLAZLjMDh8xzxwx3EPDGFq4XLK0MXw1/a9XF1uT5q8GfFzx54R8V6n4n8JeIvEfhXxBO+rJcagmlva2eja1pctub220aXUp7IW8lxqOl3V6+l6rJc3egazczw6SizRRPbfXfwV/aP8Qax4z+HPgjxl4T0rxrpmrfEO1tj4r8V6T4416+tPCt5odhYR3B8H6ffXei6/Do+jRw62ftzSzz2mjtFvVbUXley/CL4Aab8UvgX4R0Dxh4um8G+CtYvPHmo6dc6Nqmm6jpc97Y6F4Zm0+48ZxXmkeIrTz7yRdZiuba6vo9Ta306wjuNPsrmGC8H5jeKfgH448J/Hyy+A2k3vh608ReM7pG8KeKtXvbPRfA974a1XTry/tvF9/qurNdadomk2ulSTXAgkkn1TS9SU6LbKNaWCM+3hKNHFWSUaaSVZQryjKMuX2bTfLrCbi4ezqSp+84+61VjzH9DZlR4ayDJ3wdkeFpxwvBWBw/CuXUsuo4p1cnyHK/ruVZcsNj8RUjia+U5DRVHByyqjmeYSybLsJlmBqKvhKEsZU+tvCMHwa+HfipvBt38VvBviLwPq+j+J/HXgjXI7garbabp+leMtR0HUPh/q08No/wBu12wgj0rWvCkdlBBq2oaJqi2t3pGm6paSWjfXnwW+J37OPiDxbZeH7+68X+E7WXTL/Wk8R6p4A14QXem6ZY3uoSS2OixvJ4juoJLewmYXMdh5FtAsl27FLeaNfn/wB4L+Fn7OcvhOT4r+LNOv/jVrfhnXviBcXms6Be+IvCWk+Dta0y9/sXQ/Csx0XxK3wu+IOqrZR6rBdeILUSXzeKG1K8OkrplnHq3q3xe/ay+HHxJ+GWs6tB4sisPiBpsGmaH4f05fDVnpUWmW9/Pp2seL/Ehe1ubqx07U/iTqEl2h8XaTPpsvhHwl4Ui8PzeG1l8RXk0XzmcZFhc0r1amNxWbvDqFBrC0MbLBUK0YxXtW6tKm8Rz14qEZQdGk4zd6EY05KVH+LcZ9AHwD458QuIuM3w5xbUzHxAzSeMzDEcO5jhMi4fyDiTHutSzDiLC5Vg+Gszq5nh82zhVs7zSeNzXC5VHEPNcRQwtKvm+JVT+UD/gpx8VP2gPif+0j4kf416W+heHvDup67p3wa0SzstNbw7p/w2udRN5oY0LxLpmlaani9LmwexutQ1u5ae6lv5pxLHYsWs4vhZPAnil/A8/xHOmCLwbB4ih8JrrFxe2Ft9s8QS2L6k+naZY3F1HqOqvZ2Sx3GpTadaXNvpaXVj/aEts19aiX+jX49/Bnw78Ufh9beFvFguPFktlJeeNvBOlR6raeHpY7pLG7u7Dw3pusJpV9fWfhfUbaeOG5SGwmvbSxmtoILiJLS0lg/nX8e+OdY8Z39nBeWdloOieG7ebSPDPg7Ro57fQfCunm4ea4s9Pt7ie5uZbu7vGku9X1bULm71bV793utRvJ3EQi/pbgnF0quQZRgcuwOGwFDL8LhqFanSh7PDwpU4Sivq9D2sqyr4ucJ161StKUKdapiqkquLrVo2/ydyTP8DiuIuOeCcqzTIs7qeGnHHEXBeM4hyCOJXD/ABHl2QZ1m2T5dxJw9SxNOhXWEz9ZTiaklfEYPL8fg81w+HxmZYZ5VisX/veUUUV9ufZn+APX9lH7Iuq/8EK/jR+yB8G/hZ4J8c+Gf2X/AI9+H/DOmTfFS++NnjnXPh/8R/EnxVk0q0i8ba3/AMLI1hdQ+EfjLwNqurW8174Q0NYtFGh6G1rYSaBpeqQ6hc3X8a9FcWPwNHMcO8NXlONNyUvccU7xvZtSjJOzd1tZ6pnq5NnWacP5hSzTJ8bicvx9BSVLFYSvVw9aEZpKcFOlKLlTqRSjUpVI1qNWHu1KNRJcv9oXiv8AZs/Za+FPgL4o+NfC/wC3x+zP4i13RvBPiO98L6P/AMLu+EOpa9rWqJYubLQtIt/D/iZJb7UdTCizso4dMublpPL8lUkJJ+IoPiBYp8N/Bng06PJFqXg3XbvWB5sW7T9ei17bJq0WotHeQTKLeOy0e0s4miSRo45ZFvYvMjth/M1X7Wf8Eq/An7Rv7dnxcP7MXw/g8Gapf+Gfh54r+Il/418eeJJ/D8PhjwZ4RisYrh9R+x2Orat4qMmo6lpGkWVho+l3WsxC+W+u5V0bTNQuLf8AOs/4Cw86UcVhJVa86LdStGpVjCpJU4TUJRv+6nGnCVROk/Zt83NTftG2/wCvvo+/SUlwjnmfPjLE0p43iPG5LjIcSY2jiayjWybL8TlGEwGYVcv9niMJgaWEx2KnhauGwv1WhXxWOrYihGviHjpfoN8NvjH4i8H6h4Z1PQtbu9WbQ7jSrq48L6jrt5Jo11bRwXV3d6JPokWpeGdWVbqWw05b6TRL6+uooYbW9truO9isQnvv7R7w+NPgZ8NvjbbTfD7wp4n8N+H9Rvfin8M9K1fU9J8Q+I/C/wARPHOk6F4aN9aeKtV/4SvWNO1gw2ninTpE09dMvfCEl3bx3dyNPu7q/wDmr4m/si/tIfB/UZrXxt8JtccWjyQyaz4MntfH+iKkJLLdWmoeG1uL2CEYRraW906yuWcpFLBGw2rufA39jL9r/wDbW1bWfhB8MPDsXg6PUtK1Wwf4lfFnR/EXhn4ereTE6loGgo9tpF3qg1B9Wt9P0+0svBmg3jQS3+oatr1zbWFq8rfBQySSxVGFKMZudanRXNFRqUoVJqNT2kvZy5KfJKUm4uKg6cW1a8n/AHDm3jTwhmWU4nimvxBk2Fp5bgcXjsdisFm2XY2hmkVhsby4DCUqGZ0sVi8VWqzwlHDUsXgp5jOdSnGjTSoylT8LvvHOvagNPm1ex0W9urHSNI0N4Utls420vRoj9nsrWTQotDNtbBmbYsQlK2UcWliWOygiiD5vF95qNzYnU47S4ghQRajLqsK+IhM188S3mpXFpfxM1yscUUAtNP8AOmiQ20dtHLEPMRfvf9maH/gkHqvwB0L9mf46/Eiz+Af7cPwRv/FPw8/aO1z43fF7xHoF74i+LXhjxDqeg+J9Q8BfFzTL/XfhDr/w9S7sRa+D9KY2F9plhEy3VtfSTSard9rP+xT+wxpZg1rXP+Cg/wAEdD8IbpCNUn/aR+AuoyzQebwWvEe4vnaMhlSQ6c8rYyqFgpP0GO4Tq0a06P1StVTdoVsPTxLjJNP34OSm43unu7KMUuXc/BMl+mLwvWy32GOljsFSq4fFYbE5ZmHD2Gx9KrhsdQlQxOGeIyrNaNNwhSqYihS5KOEqOniKiqzqS5fZ/AnxW+O/gTw54Qv/ABFY3DJfeAfg78TX0LxP43jEd3r/AMTdbla70KC6lmt4pop9Ygs4103SLa6lsZLhk0y2SOO3M1x/MdPPLczzXM7mSe4lknmkbG6SWV2kkc4AGWdixwAMngV/Q5/wV/8AGf8AwSfsvgd8MPg1+xz418c/Gb9o/wAK+PrjWPGvxe0DxT4k1T4QXPgu50m8tdR0PW7jxFaaRo/i7xSNZXS7nwnqXgLw5Y6RoOkDXLe813Vf7UtrWD+d6vv+DOHlkGArKVStOrjasK04VlrQjTjUjGnFu0mpupKrO8YRU+VQioRsfwn40cTcJ8deJmYcZ8K8P0sgwtfhnhThSOHo0MFg8NLA8I089p5esDluAwmDwmUYCEM+rwpZbh6MaVOdFYjlpVK8qFP/AH+KKKK+wPzI/wAAeiiigArufht8TfiL8HPG2gfEn4T+OvFnw2+IHha8+3+HfGfgjX9T8M+JdFu9jxPLp+saRc2l9bedBJJb3MaTCK5tpZra4SWCWSNuGoo30eqfR6oD9rvCf/BwV/wU48O21vBrvxT+HnxOuLYgpqvxN+CPwt8R63KqxmMC71a18NaVfX0hz5j3V7NPezSjzJ7mVixbzn4v/wDBcT/gpr8Y9C1LwrfftIap8O/DOsWF3pmqaP8ABXwx4T+Eb32n32VubKfXvBWj6Z4q+yyRFrdrePXo4HgeSOSNxI+78l6K5o4PCRn7SOFw8Z3vzqhSUr73vyb31v3NHWqtWdWo0lbWcnp2ve9vK9vUfJJJNJJNNI8ssrvJLLI7PJJI7FnkkdiWd3YlndiWZiSSSSaZRRXSZhRRRQB/v8UUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAf/9k=",
                                    "type": "_img"
                                },
                                {
                                    "value": "",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 11,
                            "timeLong": 0,
                            "questionID": 3519,
                            "type": 5,
                            "option": [
                                []
                            ]
                        }
                    ]
                }
            ],
            "type": "singleTypeQues"
        },
        {
            "quesCount": 3,
            "timeLong": "0",
            "partName": "判断题",
            "quesScore": "15.0",
            "data": [
                {
                    "count": "3",
                    "score": "15.0",
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1. 发音是否相同read eat",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 12,
                            "timeLong": 0,
                            "questionID": 3523,
                            "type": 4,
                            "option": [
                                [
                                    {
                                        "value": "正确",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "错误",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "2. 发音是否相同funny shy",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 13,
                            "timeLong": 0,
                            "questionID": 3522,
                            "type": 4,
                            "option": [
                                [
                                    {
                                        "value": "正确",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "错误",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "3. She is shy and quiet",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 14,
                            "timeLong": 0,
                            "questionID": 3521,
                            "type": 4,
                            "option": [
                                [
                                    {
                                        "value": "正确",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "错误",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        }
                    ]
                }
            ],
            "type": "compQues"
        },
        {
            "quesCount": 5,
            "timeLong": "0",
            "partName": "完型填空",
            "quesScore": "10.0",
            "data": [
                {
                    "desc": [
                        {
                            "value": "In Tom’s class,every student 1 a pen pal. His teacher, Miss White, 2 them to send 3 once a week. Tom knows his pen pal goes to school 4 taxi. And his pen pal’s mother is a nurse. His pen pal’s father is a doctor. They live in front 5 the car factory.",
                            "type": "_str"
                        }
                    ],
                    "count": "5",
                    "score": "10.0",
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 15,
                            "timeLong": 0,
                            "questionID": 3525,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. has",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. have",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. is",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "2.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 16,
                            "timeLong": 0,
                            "questionID": 3526,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. help",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. helps",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. helping",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "3.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 17,
                            "timeLong": 0,
                            "questionID": 3527,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. letters",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. letter",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. books",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "4.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 18,
                            "timeLong": 0,
                            "questionID": 3528,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. on",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. by",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. with",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "5.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 19,
                            "timeLong": 0,
                            "questionID": 3529,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. to",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. in",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. of",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        }
                    ]
                }
            ],
            "type": "compQues"
        },
        {
            "quesCount": 5,
            "timeLong": "0",
            "partName": "阅读理解",
            "quesScore": "10.0",
            "data": [
                {
                    "desc": [
                        {
                            "value": "Dear Mummy, How are you？I am fine at school. Tomorrow is National Day. We don’t have to go to school. I am going to take a trip with my friends in the morning. I am going to Renmin Park. I am going there by bike. It’s near our school. In the evening, I am going to watch TV. What are you going to do tomorrow? Can you tell me? Your son, Tom 根据短文内容，判断下列句子的正(T)误(F)。",
                            "type": "_str"
                        }
                    ],
                    "count": "5",
                    "score": "10.0",
                    "question": [
                        {
                            "content": [
                                {
                                    "value": "1. Tom is going to in the evening.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 16,
                            "timeLong": 0,
                            "questionID": 3541,
                            "type": 2,
                            "option": [
                                [
                                    {
                                        "value": "A. play football",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "B. play basketball",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "C. play ping-pong",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "2. Today is National Day.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 17,
                            "timeLong": 0,
                            "questionID": 3537,
                            "type": 4,
                            "option": [
                                [
                                    {
                                        "value": "正确",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "错误",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "3. Tom is going to take a trip.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 18,
                            "timeLong": 0,
                            "questionID": 3538,
                            "type": 4,
                            "option": [
                                [
                                    {
                                        "value": "正确",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "错误",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "4. Tom is going there by bus.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 19,
                            "timeLong": 0,
                            "questionID": 3539,
                            "type": 4,
                            "option": [
                                [
                                    {
                                        "value": "正确",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "错误",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        },
                        {
                            "content": [
                                {
                                    "value": "5. Tom is going to buy some food.",
                                    "type": "_str"
                                }
                            ],
                            "serNo": 20,
                            "timeLong": 0,
                            "questionID": 3540,
                            "type": 4,
                            "option": [
                                [
                                    {
                                        "value": "正确",
                                        "type": "_str"
                                    }
                                ],
                                [
                                    {
                                        "value": "错误",
                                        "type": "_str"
                                    }
                                ]
                            ]
                        }
                    ]
                }
            ],
            "type": "singleTypeQues"
        },
        {
            "quesCount": 1,
            "partName": "书面表达",
            "quesScore": "10.0",
            "data": [
                {
                    "count": "1",
                    "score": "10.0",
                    "questionMes": "1. 假设你叫Mike, 向你的新笔友Jack介绍一下你自己。数字可以用阿拉伯数字表示。开头和结尾已写好。不少于50个单词。"
                }
            ],
            "type": "singleTypeQues"
        }
    ],
    "totalScore": "100.0",
    "paperName": "标准考试试卷",
    "totalCount": "33",
    "totalTimeLong": "60"
}）