--课后作业
local myHomeworkListPage = class("myHomeworkListPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
myHomeworkListPage.__index = myHomeworkListPage
myHomeworkListPage._uilayer = nil
function myHomeworkListPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function myHomeworkListPage:onEnter()
   
end

function myHomeworkListPage:onExit()
end

function myHomeworkListPage.create()
    local scene = myHomeworkListPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function myHomeworkListPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("testListSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    self:initList()
    return self._uilayer
end
function myHomeworkListPage:initButton()
    -- body
   require "control" 
    local ButtonBack=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
   ButtonBack:addClickEventListener(function() goUI(_allUI.mainPage) end)--返回主页
   local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
   _name:setString(_title)
end
function myHomeworkListPage:initList()--初始化list列表
    -- body
    local _listView=self._uilayer:getChildByName('ListView')
    local _node=self._uilayer:getChildByName('item_node')
    local _item=_node:getChildByName('item_node')
    for i = 1, #_paperDetail do
        local _temp_date=_paperDetail[i]
        local paperstatus=_temp_date['paperstatus']
        local papertype=_temp_date['papertype']
        local examlevel=_temp_date['examlevel']
        local examcode=_temp_date['examcode']
        local expiredate=_temp_date['expiredate']
        local papername=_temp_date['papername']
        local paperid=_temp_date['paperid']
        local studentid=_temp_date['studentid']
         local _items = _item:clone();
         local _name=_items:getChildByName('name')
         _name:setString(papername)
         local _button_test=_items:getChildByName('Button_test')
         _button_test:addClickEventListener(function ( ... )
             -- body
             kaoshi(examcode,studentid,function ( code,data )
                 -- body
                 if code==200 then  
                -- paperData._examCode=examcode
                -- paperData._studentId=studentid
                require "control" goUI(_allUI.myLianXiPage) end
             end)
             

         end)
         local _button_lock=_items:getChildByName('Button_lock')
         if paperstatus==0 then 
            _button_test:setVisible(false)
            _button_lock:setVisible(true)
         end 
        _listView:pushBackCustomItem(_items);
    end
end
function myHomeworkListPageCreate()
    return myHomeworkListPage.create()
end



