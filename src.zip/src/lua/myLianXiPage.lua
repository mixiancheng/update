-------------------------------------
local myLianXiPage = class("myLianXiPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
myLianXiPage.__index = myLianXiPage
myLianXiPage._uilayer = nil
require 'paperData'
local _partName=nil--部分名称
local _answer_Layer=nil
local _totalTimeLong=nil
local _name=''--试卷名称
local _time=''
local _jindu=''
local _biaoji=''
local _isPlayMes=false--是否在播放语音
local _questionID=''
local _questionType=''
local _layer=nil 
---------------------------------------------
function myLianXiPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function myLianXiPage:onEnter()
   
end

function myLianXiPage:onExit()
    -- myTime.Stop()
end

function myLianXiPage.create()
    local scene = myLianXiPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function myLianXiPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("myLianXiPage.csb")
    partNameLayer=self._uilayer:getChildByName('partName')
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    self:initanswerLayer()
    _questionIndex=1
    _dataIndex=1
    _paperPartsIndex=1
    -- local _animation=cc.CSLoader:createTimeline("musicAni.csb")
    -- local _node=self._uilayer:getChildByName('FileNode_1'):getChildByName('Node')
    --     _node:runAction(_animation)
    --     _animation:play("play", true)
    return self._uilayer
end
local function stopSpeaking(  )
    -- body
    local luaoc = require "cocos.cocos2d.luaoc"
            local className = "RootViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"stopSpeaking",args)
            _isPlayMes=false
end
function myLianXiPage:initButton()
    ----------------------------------------返回按钮
    local _button_back=self._uilayer:getChildByName('Button_back')
    _button_back:addClickEventListener(function ( ... )
        -- body
        dellEditBox()
        stopSpeaking()

        -- ccs.ActionManagerEx:getInstance():playActionByName("myLianXiPage.csb","showMes")
        -- myTime.Stop()
        require 'control' goUI(_SceneInfo_old)
    end)
    ----------------------------------------返回按钮
    local _button_up=self._uilayer:getChildByName('Button_up')
    _button_up:addClickEventListener(function ( ... )
        -- body
        print("up------------------")
        _layer.sub_answer()
        self:last_question()
    end)
    local _button_next=self._uilayer:getChildByName('Button_next')
    _button_next:addClickEventListener(function ( ... )
        -- body
        print("next------------------")
        _layer.sub_answer()
        self:next_question()
    end)
    local _button_tijiao=self._uilayer:getChildByName('Button_tijiao')
    _button_tijiao:addClickEventListener(function ( ... )
        -- body
        print("tijiao------------------")
        -- _xiaolvAnimation = cc.CSLoader:createTimeline("myLianXiPage.csb")
        -- self._uilayer:runAction(_xiaolvAnimation)
        -- _xiaolvAnimation:play("animation0", false)
        _layer.sub_answer()
        paperData.submitOne(function ( code,data)
            -- body
            print("submitOne---->"..data)
            local _data=json.decode(data)
            local _result=_data['result']
            local _iscorrect=_result['iscorrect']
            local _correctanswer=_result['correctanswer']
            local _score=_result['score']
            local _jifen=_result['jifen']

            local _resultLayer=cc.CSLoader:createNode("resultLayer.csb")
            local text_iscorrect=_resultLayer:getChildByName('tc_di_1'):getChildByName('Text_1')
            local text_correctanswer=_resultLayer:getChildByName('tc_di_1'):getChildByName('Text_1_0')
            local text_score=_resultLayer:getChildByName('tc_di_1'):getChildByName('Text_1_0_0')
            if _iscorrect=="N" then _iscorrect="回答错误" end 
            if _iscorrect=="Y" then _iscorrect="回答正确" end 
            text_iscorrect:setText(_iscorrect)
            text_correctanswer:setText("正确答案是:".._correctanswer)
            text_score:setText("得分:".._score)            

            self._uilayer:addChild(_resultLayer,20,9999)
            local _animation=cc.CSLoader:createTimeline("resultLayer.csb")
            _resultLayer:runAction(_animation)
            _animation:play("show", false)
            self._uilayer:runAction( cc.Sequence:create(cc.DelayTime:create(2),cc.CallFunc:create(function (  )
            -- body
            self._uilayer:removeChildByTag(9999,true)
        end)))
        end)
        
    end)
    
    local _button_ludati=self._uilayer:getChildByName('Button_loudati')
    _button_ludati:addClickEventListener(function ( ... )
        -- body
        print("loudati------------------")
    end)
    local _button_biaojiti=self._uilayer:getChildByName('Button_biaojiti')
    _button_biaojiti:addClickEventListener(function ( ... )
        -- body
        print("biaojiti------------------")
    end)
    _name=self._uilayer:getChildByName('name')
    _partName=self._uilayer:getChildByName('partName')
    _time=self._uilayer:getChildByName('time')
    _jindu=self._uilayer:getChildByName('jindu')
    _biaoji=self._uilayer:getChildByName('biaoji')
    _biaoji:addEventListenerCheckBox( function ( sender,eventType )
         -- body
         if eventType == ccui.CheckBoxEventType.selected then
         paperData.sign(1)
        elseif eventType == ccui.CheckBoxEventType.unselected then
        paperData.sign(0)
        end
    end)  --注册事件
end
function myLianXiPage:next_question()
    -- local _answer=select_Layer.get_answer()--获取答案
    -- paperData.add_answer(_answer)--添加答案
    paperData.next_question(function()--更新题目
        -- body
        paperData.get_serNoInfo(function ( _serNo,_totoalNo )
            -- body
            _jindu:setString('答题进度：'.._serNo..'/'.._totoalNo)
        end)
        paperData.isSign(function ( _boolean )--设置标记按钮
        -- body
        _biaoji:setSelected(_boolean)
        end)
        paperData.get_question(function(_qustion_item )--初始化题目
        self:add_question_layer(_qustion_item)
        end)
        --body
    end,function()--更新部分
        -- body
    end,function()--更新大部分
        -- body
        paperData.get_paperPart_name(function (paperName )
            -- body
            _partName:setString(paperName)
        end)
    end)
end
function myLianXiPage:add_question_layer(_qustion_item)--添加题目页面
    -- body
        if _answer_Layer ~=nil then
            self._uilayer:removeChildByTag(999,true) 
            _answer_Layer=nil 
        end
        -- local _examCode
        -- _questionID=_qustion_item['questionID']
        -- _questionType=_qustion_item['type']
        -- local _studentId
        ----------------------选择／填空／完形填空／阅读理解／判断／听力--------------------------
        _layer=require 'myLianXiLayer'
        local desc=paperData.getdesc()
        local questionMes=paperData.getquestionMes()
        local type=paperData.get_data_type()
        ------------------------------------播放音频
        if type=='0' then  
        paperData.playSting(self._uilayer)
        -------------------------------------------------

        _answer_Layer=_layer.getLayer(questionMes,nil,_qustion_item)
        self._uilayer:addChild(_answer_Layer,10,999)
        else 
        _answer_Layer=_layer.getLayer(nil,desc,_qustion_item)
        self._uilayer:addChild(_answer_Layer,10,999)
        end 
        -----------------------------------------------------------------------------
end
function myLianXiPage:last_question()
    -- body
    print('上一题-----------------')
        paperData.get_serNoInfo(function ( _serNo,_totoalNo )
            -- body
            _jindu:setString('答题进度：'.._serNo..'/'.._totoalNo)
        end)
        paperData.last_question(function()--更新题目
        -- body
        paperData.isSign(function ( _boolean )--设置标记按钮
        -- body
        _biaoji:setSelected(_boolean)
        end)
        paperData.get_question(function(_qustion_item )--初始化题目
        self:add_question_layer(_qustion_item)
        end)
        --body
    end,function()--更新部分
        -- body
    end,function()--更新大部分
        -- body
        paperData.get_paperPart_name(function (paperName )
            -- body
            _partName:setString(paperName)
        end)
    end)
end
function myLianXiPage:showQuestion()
    -- body
    paperData.get_paperInfo(function (paperName,totalCount,totalTimeLong,totalScore)
        -- body
        _name:setString(paperName)
        -- _totalTimeLong=_paperParts['totalTimeLong']or --时间
        -- require 'myTime'
        -- myTime.set_time(_totalTimeLong,function ( _boolean,_str )
        --     -- body
        --     _time:setString(_str)
        -- end)
    end)
    
end
function myLianXiPage:initanswerLayer()
    -- body
    self:showQuestion()
    paperData.indexInit()
    -- require "select_Layer"
    paperData.get_serNoInfo(function ( _serNo,_totoalNo )
            -- body
            _jindu:setString('答题进度：'.._serNo..'/'.._totoalNo)
        end)
    paperData.get_question(function ( _qustion_item )--初始化题目
        -- body
        self:add_question_layer(_qustion_item)
    end)
    paperData.get_paperPart_name(function (paperName )--设置部分名称
            -- body
            _partName:setString(paperName)
        end)
    -- paperData.isSign(function ( _boolean )--设置标记按钮
    --     -- body
    --     _biaoji:setSelected(_boolean)
    -- end)
end
function myLianXiPageCreate()
    return myLianXiPage.create()
end



