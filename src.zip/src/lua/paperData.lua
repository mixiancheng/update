module("paperData",package.seeall)--处理试卷数据
_examCode=''
_questionID=''
_questionType=''
_studentId=''
local _paperType_Kaoshi=1--考试
local _paperType_Lianxi=2--练习
local _paperType=_paperType_Kaoshi--试卷类型
local _totalTimeLong=nil--总时长
local _paperPartsIndex=1--paperParts_index部分索引
local _dataIndex=1--question_index部分下题目索引
local _questionIndex=1--题目索引
local _paperPartsMax--部分数量
local _dataMax--部分下的子部分数量
local _questionMax--题目数量
_isPlayMes=false
-- local _paperData=_paperParts--试卷数据
function indexInit()
  -- body
  _paperPartsIndex=1
  _dataIndex=1
  _questionIndex=1
end
function add_answer( _data )--设置答案
    -- body
    _paperParts['paperParts'][_paperPartsIndex]['data'][_dataIndex]['question'][_questionIndex]['user_answer']=_data
end
function get_answer( _fun )--获取用户已选答案
	-- body
	local user_answer=_paperParts['paperParts'][_paperPartsIndex]['data'][_dataIndex]['question'][_questionIndex]['user_answer']
	if user_answer~=nil and user_answer~='' then _fun(user_answer) else _fun(nil) end 
end
local function get_serNo(  )
  -- body
  local _serNo=_paperParts['paperParts'][_paperPartsIndex]['data'][_dataIndex]['question'][_questionIndex]['serNo']
   return _serNo
end
function sign( _boolean )--标记试题
    -- body
    _paperParts['paperParts'][_paperPartsIndex]['data'][_dataIndex]['question'][_questionIndex]['sign']=_boolean
end
function set_mes_isPlay( _bool )
  -- body
  _paperParts['paperParts'][_paperPartsIndex]['data'][_dataIndex]['play']=_bool
end
function get_mes_isPlay(  )
  -- body
  local _isPlay=_paperParts['paperParts'][_paperPartsIndex]['data'][_dataIndex]['play'] or 0
  return _isPlay
end
function isSign( _fun )--试题是否已标记
	-- body

	local _isSign=_paperParts['paperParts'][_paperPartsIndex]['data'][_dataIndex]['question'][_questionIndex]['sign']
	if _isSign==0  or  _isSign==nil  or _isSign=='' then  _fun(false) else _fun(true) end

end
function get_paperInfo( _fun )--获得试卷数据
	-- body
	local paperParts=_paperParts['paperParts']
    local totalScore=_paperParts['totalScore']--总分
    local paperName=_paperParts['paperName']--试卷名称
    local totalCount=_paperParts['totalCount']--总题目
    local totalTimeLong=_paperParts['totalTimeLong']--时间
   _fun(paperName,totalCount,totalTimeLong,totalScore)
end
function get_paperPartMax( ... )
  -- body
  local paperParts=_paperParts['paperParts']
    local _Max=#paperParts
    return _Max
end
function get_paperPart()--获得部分数据
    -- body
    local paperParts=_paperParts['paperParts']
    _paperPartsMax=#paperParts
    local part=paperParts[_paperPartsIndex]
    return part
end
function get_paperPart_name( _fun )--获得部分名称
	-- body
	local _part=get_paperPart(_paperPartsIndex)
	local _name=_part['partName'] or '没有部分名称'
	print('partName----'.._name)
	_fun(_name)
end
function get_dataMax(  )
  -- body
  local paperParts=get_paperPart()
    local datas=paperParts['data']
    local data=datas[_dataIndex]
    local _Max=#datas
    return _Max
end
function get_data()--获得子部分数据
    local paperParts=get_paperPart()
    local datas=paperParts['data']
    local data=datas[_dataIndex]
    _dataMax=#datas
    return data
end 
function get_serNoInfo( _fun)
  -- body
   local paperParts=_paperParts['paperParts']
   local totalCount=_paperParts['totalCount'] or 0--总题目
   local _serNo=get_serNo()
   _fun(_serNo,totalCount)
end
function getdesc(  )
  -- body
  local datas=get_data()
  local desc=datas['desc']
  return desc
  -- _fun(desc)
end
function get_data_type(  )
  -- body
  local datas=get_data()
  local desc=datas['type']
  return desc
end
function getquestionMes(  )
  -- body
  local datas=get_data()
  local desc=datas['questionMes']
  return desc
  -- _fun(desc)
end
function get_questionMax(  )
  -- body
  local datas=get_data()
    local data=datas['question']
    local _Max=#data
    return _Max
end
function get_question(_fun)--获得题目
    -- body
    -- sign(1)
    local datas=get_data()
    local data=datas['question']
    _questionMax=#data
    local question=data[_questionIndex]
    _fun(question)
end
local function next_part(_fun_changeQuestion,_fun_changeData,_fun_changePart)--切换至下一大部分
    -- body
    if _paperPartsIndex==_paperPartsMax then    
     print('----试卷结束----')
     else
    _questionIndex=1
    _dataIndex=1
    _paperPartsIndex=_paperPartsIndex+1
    _fun_changePart()
    _fun_changeData()
    _fun_changeQuestion()
    end
    
end
local function next_data(_fun_changeQuestion,_fun_changeData,_fun_changePart)--切换至下一部分
    -- body
    if _dataIndex==_dataMax  then  next_part(_fun_changeQuestion,_fun_changeData,_fun_changePart)  else
    _questionIndex=1
    _dataIndex=_dataIndex+1
    _fun_changeQuestion()
    _fun_changePart()
    end
end
local function last_part( _fun_changeQuestion,_fun_changeData,_fun_changePart )
    -- body
     if _paperPartsIndex==1 then    
     print('----试卷结束----')
     else
    _paperPartsIndex=_paperPartsIndex-1
    _dataIndex=get_dataMax()
    _questionIndex=get_questionMax()
    -- _dataIndex=1
    _fun_changePart()
    _fun_changeData()
    _fun_changeQuestion()
    end
end
local function last_data( _fun_changeQuestion,_fun_changeData,_fun_changePart )
    -- body
    if _dataIndex==1  then  last_part(_fun_changeQuestion,_fun_changeData,_fun_changePart)  else
    _dataIndex=_dataIndex-1
    local _max=get_questionMax()
    _questionIndex=_max--需修改
    _fun_changeQuestion()
    _fun_changeData()
    end
end
function next_question(_fun_changeQuestion,_fun_changeData,_fun_changePart)
    -- body
    print('下一题-----------------')
    if _questionIndex==_questionMax  then 
      print('212122')
      if _isPlayMes==false then 
        print('dasdasda')
       next_data(_fun_changeQuestion,_fun_changeData,_fun_changePart) 
       end 
   else
    _questionIndex=_questionIndex+1
    _fun_changeQuestion()
    end
end
function last_question(_fun_changeQuestion,_fun_changeData,_fun_changePart)
    -- body
    print('上一题-----------------')
    if _questionIndex==1 then 
    if _isPlayMes==false then 
    last_data(_fun_changeQuestion,_fun_changeData,_fun_changePart) 
    end
    else
    _questionIndex=_questionIndex-1
    _fun_changeQuestion()
    end
end
-- "questionID":"2342", "questionType":"2", "answer":"C", "timeLong":"30"
function format_answer(_fun)
	-- body
	local answers={}
	local _paper_parts=_paperParts['paperParts']
	for i,v in ipairs(_paper_parts) do
       local _paper_parts_data=v['data']
          for c,b in ipairs(_paper_parts_data) do
              local _questions=b['question']
              for h,m in ipairs(_questions) do
              	if m['user_answer']~=nil then 
              	   local questionID=m['questionID']
              	   local questionType=m['type']
              	   local timeLong='30'
              	   local answer=m['user_answer']
              	   local _table_temp={}
              	   _table_temp['questionID']=questionID
              	   _table_temp['questionType']=questionType
              	   _table_temp['answer']=answer
              	   _table_temp['timeLong']=timeLong
              	   print('questionID:'..questionID.." questionType:"..questionType)
              	   table.insert(answers,_table_temp)
              	end 
              end
          end
	end
_fun(answers)
end
function table_copy_table(ori_tab)  
    if (type(ori_tab) ~= "table") then  
        return nil  
    end  
    local new_tab = {}  
    for i,v in pairs(ori_tab) do  
        local vtyp = type(v)  
        if (vtyp == "table") then  
            new_tab[i] = table_copy_table(v)  
        elseif (vtyp == "thread") then  
            new_tab[i] = v  
        elseif (vtyp == "userdata") then  
            new_tab[i] = v  
        else  
            new_tab[i] = v  
        end  
    end  
    return new_tab  
end  
function format_answer_one(_fun)
  -- body
  local answers={}
  local _paper_part=_paperParts['paperParts'][_paperPartsIndex]
       local _paper_parts_data=_paper_part['data'][_dataIndex]
              local _questions=_paper_parts_data['question']
              local m=_questions[_questionIndex]
                if m['user_answer']~=nil then 
                   local questionID=m['questionID']
                   local questionType=m['type']
                   local timeLong='30'
                   local answer=table_copy_table(m['user_answer'])
                   for i,v in ipairs(answer) do
                      if answer[i]['result']==1 then answer[i]['result']="A" end 
                      if answer[i]['result']==2 then answer[i]['result']="B" end 
                      if answer[i]['result']==3 then answer[i]['result']="C" end 
                      if answer[i]['result']==4 then answer[i]['result']="D" end 
                   end
                   print('questionID:'..questionID.." questionType:"..questionType)
                   _fun(questionID,questionType,timeLong,answer)
                end
               -- _fun(questionID,questionType,timeLong,answers)
end
function submit(_fun)
	-- body
	  format_answer(function ( _answers)
		-- body
		submitPaper(_answers,function ( code,data )
			-- body
       _fun()
		end)
	end)
end
function submitOne(_fun)
  -- body
    format_answer_one(function ( _questionID,_questionType,_timeLong,_answers)
    -- body
    ksSubmitPaperOne(_questionID,_questionType,_timeLong,_answers,function ( code,data )
      -- body
      if code==200 then
        print('submitOne----->'..data)
       _fun(code,data)
     end 
    end)
  end)
end
function playSting( _node)
  -- body
  local desc=getdesc()
  if paperData._isPlayMes==false and paperData.get_mes_isPlay()==0 then 

        local _animation=cc.CSLoader:createTimeline("musicAni.csb")
        local _nodeIcon=_node:getChildByName('FileNode_1')
        _nodeIcon:setVisible(true)
        _nodeIcon:runAction(_animation)
        _animation:play("play", true)
            paperData.set_mes_isPlay(1)
            paperData._isPlayMes=true
            local _index=1
            local _max=#desc
        
        local function play()
            print('play--------------------')
            -- body
            local function progress( _per )
            -- body
            print('lua-------play'.._per)
            if _per==100 then 
                -- _isPlayMes=false
                _index=_index+1
                if _index<=_max then 
                _node:runAction( cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(play)))
                else
                    paperData._isPlayMes=false
                    _animation:stop()
                    _nodeIcon:setVisible(false)
                end 
            end
            end
            local _name='Catherine'--henry
            local _type=desc[_index]['role']
            if _type=="M" then _name="henry" end
            local args = { num1 = desc[_index]['value'].." ",num2=progress,name=_name}
            -- local args = { num1 = "Hi Peter Who is that boy in green ",num2=progress}
            local luaoc = require "cocos.cocos2d.luaoc"
            local className = "RootViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"playMes",args)
            
        end
        play()
      end
end
