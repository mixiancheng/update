module("questionLayer",package.seeall)
function get_Layer( _question )
	-- body
end