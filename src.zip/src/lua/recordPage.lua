--我的记录
local recordPage = class("recordPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
recordPage.__index = recordPage
recordPage._uilayer = nil
function recordPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function recordPage:onEnter()
   
end

function recordPage:onExit()
end

function recordPage.create()
    local scene = recordPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function recordPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("recordSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    self:initList()
    return self._uilayer
end
function recordPage:initButton()
    -- body
require "control" 
    local ButtonBack=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
   ButtonBack:addClickEventListener(function() goUI(_allUI.mainPage) end)--返回主页
   local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
   _name:setString(_title)
end
function recordPage:initList()--初始化list列表
    -- body
    local _listView=self._uilayer:getChildByName('ListView')
    local _node=self._uilayer:getChildByName('item_node')
    local _item=_node:getChildByName('item_node')
    for i = 1, #_recordsDetail do
        local _temp_data=_recordsDetail[i]
        local _examtimelong=_temp_data['examtimelong']--答题时间
        local _examname=_temp_data['examname']--试卷名称
        local _ranking=_temp_data['ranking']--排名
        local _getscore=_temp_data['getscore']--成绩
        local _examCode=_temp_data['examcode']--答案id
        local _studentid=_temp_data['studentid']--学生id
         local _items = _item:clone();
         local _name=_items:getChildByName('name')
         _name:setString(_examname)
         local _rank=_items:getChildByName('rank')
         _rank:setString(_ranking)
         local _score=_items:getChildByName('score')
         _score:setString(_getscore)
         local _button_rank=_items:getChildByName('Button_rank')
         _button_rank:addClickEventListener(function (...)
             -- body
             print('examCode=='.._examCode)
             get_zhishidianRank(_examCode,_studentid,function ( code ,data  )
                 -- body
                 goUI(_allUI.zsdpaimingPage)
             end)
         end)
         local _button_ck=_items:getChildByName('Button_da')
         _button_ck:addClickEventListener(function ( ... )
             -- body
             print('-----------------查看答案----------------')
             print('examCode--->'.._examCode)
              print('_studentid--->'.._studentid)
              myAnswer(_examCode,_studentid,function ( code,data )
                  -- body
                  if code==200 then  require "control" goUI(_allUI.myAnswerPage) end
              end)
              -- get_zhishidianRank(_examCode,_studentid,function ( code,data )
              --     -- body
              --     if code==200 then  require "control" goUI(_allUI.zsdpaimingPage) end 
              -- end)
             
         end)
         local _button_bg=_items:getChildByName('Button_bg')
         _button_bg:addClickEventListener(function ( ... )
             -- body
             print('-----------------查看报告----------------')
              
              get_baogao(_examCode,_studentid,function ( code,data )
                  -- body
              print('examCode--->'.._examCode)
              print('_studentid--->'.._studentid)
              goUI(_allUI.baogaoPage)
              end)
         end)
        _listView:pushBackCustomItem(_items);
    end
end
function recordPageCreate()
    return recordPage.create()
end



