-------------------------------------
--  StartGame Test
-------------------------------------
local scoreSc = class("scoreSc",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
scoreSc.__index = scoreSc
scoreSc._uilayer = nil
function scoreSc:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function scoreSc:onEnter()
   
end

function scoreSc:onExit()
end

function scoreSc.create()
    local scene = scoreSc.new()
    scene:addChild(scene:createLayer())
    return scene
end

function scoreSc:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("scoreSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    local Button_fenxizhongxin=self._uilayer:getChildByName('Button_fenxizhongxin')
    Button_fenxizhongxin:addClickEventListener(function ( ... )
        -- body
        analysisCenter(_examCode,function ( code,data)
            -- body
            if code==200 then   goUI(_allUI.fxzxPage) end 
        end)
    end)
    local Button_back=self._uilayer:getChildByName('Button_back')
    Button_back:addClickEventListener(function ( ... )
        -- body
        require 'control' goUI(_allUI.mainPage)
    end)
    if _paper_kaoshi_result==nil  or   _paper_kaoshi_result=='' then 
    else
    local score=_paper_kaoshi_result['score']
    local rights=_paper_kaoshi_result['rights']
    local counts=_paper_kaoshi_result['counts']
    local wrongs=_paper_kaoshi_result['wrongs']
    local Text_score=self._uilayer:getChildByName('Text_score')
    Text_score:setString(score..'分')
    local Text_nums=self._uilayer:getChildByName('Text_nums')
    Text_nums:setString('完成题数：'..counts)
    local Text_yes=self._uilayer:getChildByName('Text_yes')
    Text_yes:setString('答对题数：'..rights)
    local Text_no=self._uilayer:getChildByName('Text_no')
    Text_no:setString('答错题数：'..wrongs)
    end 
    return self._uilayer
end
function scoreScCreate()
    return scoreSc.create()
end



