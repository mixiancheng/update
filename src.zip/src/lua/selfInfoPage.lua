--个人中心（我的课表）
local selfInfoPage = class("selfInfoPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
selfInfoPage.__index = selfInfoPage
selfInfoPage._uilayer = nil
function selfInfoPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function selfInfoPage:onEnter()
   
end

function selfInfoPage:onExit()
end

function selfInfoPage.create()
    local scene = selfInfoPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function selfInfoPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("kebiaoSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    self:initList()
    return self._uilayer
end
function selfInfoPage:initButton()
    -- body
    require "control" 
    local ButtonBack=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
   ButtonBack:addClickEventListener(function() goUI(_allUI.mainPage) end)--返回主页
   local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
   _name:setString(_title)

end
function selfInfoPage:initList()--初始化list列表
    -- body
    local _listView=self._uilayer:getChildByName('ListView')
    local _node=self._uilayer:getChildByName('item_node')
    local _item=_node:getChildByName('item_node')
    for i = 1, #_kebiao_data do
        local _temp=_kebiao_data[i]
         local _items = _item:clone();
         local _date=_items:getChildByName('date')
         _date:setString(_temp['class_date'])
         local _time1=_items:getChildByName('time1')
          _time1:setString(_temp['class_begin_date'])
         local _time2=_items:getChildByName('time2')
          _time2:setString(_temp['class_end_date'])
         local _teacher1=_items:getChildByName('teacher1')
          _teacher1:setString(_temp['teacher_name'])
         local _teacher2=_items:getChildByName('teacher2')
          _teacher2:setString(_temp['assistant_ids'])
         local _button_l1=_items:getChildByName('Button_l1')
         local _button_l2=_items:getChildByName('Button_l2')
         local _button_c1=_items:getChildByName('Button_c1')
         local _button_c2=_items:getChildByName('Button_c2')
        _listView:pushBackCustomItem(_items);
    end
end
function selfInfoPageCreate()
    return selfInfoPage.create()
end



