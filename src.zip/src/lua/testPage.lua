-------------------------------------
local testPage = class("testPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
testPage.__index = testPage
testPage._uilayer = nil
require 'paperData'
local _partName=nil--部分名称
local _answer_Layer=nil
local _totalTimeLong=nil
local _name=''--试卷名称
local _time=''
local _jindu=''
local _biaoji=''
-- _isPlayMes=false--是否在播放语音
local _layer=nil
---------------------------------------------
function testPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function testPage:onEnter()
   
end

function testPage:onExit()
    myTime.Stop()
    paperData._isPlayMes=false
end

function testPage.create()
    local scene = testPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function testPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("testSc.csb")
    partNameLayer=self._uilayer:getChildByName('partName')
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    self:initanswerLayer()
    _questionIndex=1
    _dataIndex=1
    _paperPartsIndex=1
    return self._uilayer
end
local function stopSpeaking(  )
    -- body
    local luaoc = require "cocos.cocos2d.luaoc"
            local className = "RootViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"stopSpeaking",args)
            paperData._isPlayMes=false
end
function testPage:initButton()
    ----------------------------------------返回按钮
    local _button_back=self._uilayer:getChildByName('Button_back')
    _button_back:addClickEventListener(function ( ... )
        -- body
        dellEditBox()
        stopSpeaking()
        myTime.Stop()
        require 'control' goUI(_SceneInfo_old)
    end)
    ----------------------------------------返回按钮
    local _button_up=self._uilayer:getChildByName('Button_up')
    _button_up:addClickEventListener(function ( ... )
        -- body
        print("up------------------")
        self:last_question()
    end)
    local _button_next=self._uilayer:getChildByName('Button_next')
    _button_next:addClickEventListener(function ( ... )
        -- body
        print("next------------------")
        self:next_question()
    end)
    local _button_tijiao=self._uilayer:getChildByName('Button_tijiao')
    _button_tijiao:addClickEventListener(function ( ... )
        -- body
        _layer.sub_answer()
        print("tijiao------------------")
        paperData.submit(function ( ... )
            -- body
            myTime.Stop()
            goUI(_allUI.scorePage)
        end)
        
    end)
    
    local _button_ludati=self._uilayer:getChildByName('Button_loudati')
    _button_ludati:addClickEventListener(function ( ... )
        -- body
        print("loudati------------------")
    end)
    local _button_biaojiti=self._uilayer:getChildByName('Button_biaojiti')
    _button_biaojiti:addClickEventListener(function ( ... )
        -- body
        print("biaojiti------------------")
    end)
    _name=self._uilayer:getChildByName('name')
    _partName=self._uilayer:getChildByName('partName')
    _time=self._uilayer:getChildByName('time')
    _jindu=self._uilayer:getChildByName('jindu')
    _biaoji=self._uilayer:getChildByName('biaoji')
    _biaoji:addEventListenerCheckBox( function ( sender,eventType )
         -- body
         if eventType == ccui.CheckBoxEventType.selected then
         paperData.sign(1)
        elseif eventType == ccui.CheckBoxEventType.unselected then
        paperData.sign(0)
        end
    end)  --注册事件
end
function testPage:next_question()
    _layer.sub_answer()
    -- local _answer=select_Layer.get_answer()--获取答案
    -- paperData.add_answer(_answer)--添加答案
    paperData.next_question(function()--更新题目
        -- body
        paperData.get_serNoInfo(function ( _serNo,_totoalNo )
            -- body
            _jindu:setString('答题进度：'.._serNo..'/'.._totoalNo)
        end)
        paperData.isSign(function ( _boolean )--设置标记按钮
        -- body
        _biaoji:setSelected(_boolean)
        end)
        paperData.get_question(function(_qustion_item )--初始化题目
        self:add_question_layer(_qustion_item)
        end)
        --body
    end,function()--更新部分
        -- body
    end,function()--更新大部分
        -- body
        paperData.get_paperPart_name(function (paperName )
            -- body
            _partName:setString(paperName)
        end)
    end)
end
function testPage:add_question_layer(_qustion_item)--添加题目页面
    -- body
        if _answer_Layer ~=nil then
            self._uilayer:removeChildByTag(999,true) 
            _answer_Layer=nil 
        end
        ----------------------选择／填空／完形填空／阅读理解／判断／听力--------------------------
        _layer=require 'select_Layer'
        local desc=paperData.getdesc()
        local questionMes=paperData.getquestionMes()
        local type=paperData.get_data_type()
        ------------------------------------播放音频
        if type=='0' then  --听力题
        paperData.playSting(self._uilayer)
        -- end 
        -------------------------------------------------

        _answer_Layer=_layer.getLayer(questionMes,nil,_qustion_item)
        self._uilayer:addChild(_answer_Layer,10,999)
        else 
        _answer_Layer=_layer.getLayer(nil,desc,_qustion_item)
        self._uilayer:addChild(_answer_Layer,10,999)
        end 
        -----------------------------------------------------------------------------
end
function testPage:last_question()
    -- body
    print('上一题-----------------')
        _layer.sub_answer()
        paperData.last_question(function()--更新题目
        -- body
        paperData.get_serNoInfo(function ( _serNo,_totoalNo )
            -- body
            _jindu:setString('答题进度：'.._serNo..'/'.._totoalNo)
        end)
        
        paperData.isSign(function ( _boolean )--设置标记按钮
        -- body
        _biaoji:setSelected(_boolean)
        end)
        paperData.get_question(function(_qustion_item )--初始化题目
        self:add_question_layer(_qustion_item)
        end)
        --body
    end,function()--更新部分
        -- body
    end,function()--更新大部分
        -- body
        paperData.get_paperPart_name(function (paperName )
            -- body
            _partName:setString(paperName)
        end)
    end)
end
function testPage:showQuestion()
    -- body
    paperData.get_paperInfo(function (paperName,totalCount,totalTimeLong,totalScore)
        -- body
        _name:setString(paperName)
        _totalTimeLong=_paperParts['totalTimeLong']--时间
        require 'myTime'
        myTime.set_time(_totalTimeLong,function ( _boolean,_str )
            -- body
            _time:setString(_str)
        end)
    end)
    
end
function testPage:initanswerLayer()
    -- body
    self:showQuestion()
    paperData.indexInit()
    -- require "select_Layer"
    paperData.get_serNoInfo(function ( _serNo,_totoalNo )
            -- body
            _jindu:setString('答题进度：'.._serNo..'/'.._totoalNo)
        end)
    paperData.get_question(function ( _qustion_item )--初始化题目
        -- body
        self:add_question_layer(_qustion_item)
    end)
    paperData.get_paperPart_name(function (paperName )--设置部分名称
            -- body
            _partName:setString(paperName)
        end)
    -- paperData.isSign(function ( _boolean )--设置标记按钮
    --     -- body
    --     _biaoji:setSelected(_boolean)
    -- end)
end
function testPageCreate()
    return testPage.create()
end



