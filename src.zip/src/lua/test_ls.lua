-------------------------------------
-------------------------------------
--  StartGame Test
-------------------------------------
local test_ls = class("test_ls",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
test_ls.__index = test_ls
test_ls._uilayer = nil
local _answer_Layer=nil
---------------------------------------------
function test_ls:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function test_ls:onEnter()
   
end

function test_ls:onExit()
end

function test_ls.create()
    local scene = test_ls.new()
    scene:addChild(scene:createLayer())
    return scene
end

function test_ls:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("testSc.csb")
    self._uilayer:setPosition(cc.p(0,0))
    local function nextScene(node)
        local  pDirector = cc.Director:getInstance()
        print('------------------')
    end
    self:initButton()
    -- self:initanswerLayer()
    return self._uilayer
end
local _name=''
local _time=''
local _jindu=''
local _biaoji=''
function test_ls:initButton()
    ----------------------------------------返回按钮
    local _button_back=self._uilayer:getChildByName('Button_back')
    _button_back:addClickEventListener(function ( ... )
        -- body
        require 'control' goUI(_SceneInfo_old)
    end)
    ----------------------------------------返回按钮
    local _button_up=self._uilayer:getChildByName('Button_up')
    _button_up:addClickEventListener(function ( ... )
        -- body
        print("up------------------")
    end)
    local _button_next=self._uilayer:getChildByName('Button_next')
    _button_next:addClickEventListener(function ( ... )
        -- body
        print("next------------------")
        if _answer_Layer ~=nil then
            self._uilayer:removeChildByTag(999,true) 
            _answer_Layer=nil 
            print('remove_select_layer')
        end
        require 'select_Layer'
        _answer_Layer=select_Layer.getLayer()
        self._uilayer:addChild(_answer_Layer,10,999)
        _answer_Layer:setPosition(84,272)
    end)
    local _button_tijiao=self._uilayer:getChildByName('Button_tijiao')
    _button_tijiao:addClickEventListener(function ( ... )
        -- body
        print("tijiao------------------")
    end)
    
    local _button_ludati=self._uilayer:getChildByName('Button_loudati')
    _button_ludati:addClickEventListener(function ( ... )
        -- body
        print("loudati------------------")
    end)
    local _button_biaojiti=self._uilayer:getChildByName('Button_biaojiti')
    _button_biaojiti:addClickEventListener(function ( ... )
        -- body
        print("loudati------------------")
    end)
    _name=self._uilayer:getChildByName('name')
    _time=self._uilayer:getChildByName('time')
    _jindu=self._uilayer:getChildByName('jindu')
    _biaoji=self._uilayer:getChildByName('biaoji')
end
local paperPartsIndex=1--paperParts_index部分索引
local QuesIndex=1--question_index部分下题目索引
-- function get_paperPart( _paperPartsIndex )--获得部分数据
--     -- body
--     local paperParts=_paperParts['paperParts']
--     local part=paperParts[_paperPartsIndex]
--     print('part------------->'..part['quesCount'])
--     return part
-- end
-- function test_ls:get_question( _paperPartsIndex,_QuesIndex)
--     -- body
--     local paperParts=get_paperPart(_paperPartsIndex)
--     print('part------------->'..paperParts['quesCount'])

--     local singleTypeQues=paperParts['singleTypeQues']

--     local singleTypeQues_item=singleTypeQues[1]
--     local count=singleTypeQues_item['count']
--     print("count---------->"..singleTypeQues_item['count'])


--     local question=singleTypeQues_item['question']
--     local question_item=question[_QuesIndex]

--     print('question_item---serNo'..question_item['serNo'])
--     return question_item
-- end
--_paperParts
function test_ls:showQuestion()
    -- body
    print('function testPage:showQuestion()')
    local paperParts=_paperParts['paperParts']
    local totalScore=_paperParts['totalScore']--总分
    local paperName=_paperParts['paperName']--试卷名称
    _name:setString(paperName)
    local totalCount=_paperParts['totalCount']--总题目
    local totalTimeLong=_paperParts['totalTimeLong']--时间
    local _ques=get_question(1,1)
    print{'_ques.serNo'.._ques['serNo']}
    print{'_ques.questionID'.._ques['questionID']}
end
function test_ls:initanswerLayer()
    -- body
    self:showQuestion()
    require "select_Layer"
    _answer_Layer=select_Layer.getLayer()
    self._uilayer:addChild(_answer_Layer,10,999)
    _answer_Layer:setPosition(84,272)
end
function test_lsCreate()
    return test_ls.create()
end



