-------------------------------------
local tuozhuaiLayer = class("tuozhuaiLayer",function()
    return cc.Scene:create()
end)
local _color=cc.c3b(90,38,12)
local _item={}
local _item2={}
local _item1={}
_item['value']='1. Looksdsdsddadsd'
_item['type']='_str'
local _content={}
table.insert(_content,_item)
 _item1['value']='2. see'
 _item1['type']='_action'
table.insert(_content,_item1)
 _item2['value']='3.the bear.'
 _item2['type']='_str'
table.insert(_content,_item2)
local _actions={}
local function RichText(_H,_tables,size)
local richText = ccui.RichText:create()
    richText:ignoreContentAdaptWithSize(false)
    richText:setContentSize(cc.size(600, _H))
    for i,v in ipairs(_tables) do
   local _temp=v
   if v.type=='_action' and v.value~=nil and v.value~='' then --文字
    local re1 = ccui.RichElementText:create( 1, _color, 255, v['value'], 'Helvetica', size )
    -- local x,y=re1:getPosition()
    -- print('x-------'..x)
    table.insert(_actions,re1)
    richText:pushBackElement(re1)
   end
   if v.type=='_str' and v.value~=nil and v.value~='' then --文字
    print('string-----------'..v.value)
    local re1 = ccui.RichElementText:create( 1, _color, 255, v['value'], 'Helvetica', size )
    richText:pushBackElement(re1)
   end
   -- if v.type=='_img' and v.value~=nil then --图片
   --  local _img=get_img_sprite(v['value'])
   --  local recustom = ccui.RichElementCustomNode:create( 1, cc.c3b(0, 0, 0), 255, _img ) 
   --  richText:pushBackElement(recustom)
   --  end
   --  if v.type=='_edit' then
   --  local len=v['value']
   --  -- local arr =ccui.EditBox:create(cc.size(len*18,30), ccui.Scale9Sprite:create("green_edit.png"))
   --  local arr =creatEditBox(len)
   --  table.insert(answer_edit,arr)
   --  local recustom = ccui.RichElementCustomNode:create( 1, cc.c3b(0, 0, 0), 255, arr ) 
   --  richText:pushBackElement(recustom)
   --  end
    end
    -- if _CheckBox~=nil then  
    --   local kong = ccui.RichElementText:create( 1, cc.c3b(0, 0, 0), 255, '      ' , 'Helvetica', 40 )
    --   richText:pushBackElement(kong)
    --   local recustom = ccui.RichElementCustomNode:create( 1, cc.c3b(0, 0, 0), 255, _CheckBox ) 
    --   richText:pushBackElement(recustom)
    -- end
    richText:setLocalZOrder(10)
    return richText
end
tuozhuaiLayer.__index = tuozhuaiLayer
tuozhuaiLayer._uilayer = nil
local _answers={}--答案{"result":1}
local _nodes={}
local _touchLayer
local _curItem
function tuozhuaiLayer:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end
local function inside(_x,_y,_w,_h,px,py)--点和矩形判断
    -- body
    -- if px<_x or px>_x+_w or py<_y or py>_y+_h then  return false end 
    if px<_x-_w/2 or px>_x+_w/2 or py<_y-_h/2 or py>_y+_h/2 then  return false end 
    return true
end
local function insideNode(_node,px,py)--点是否在控件内
    -- body
    local _x,_y=_node:getPosition()
    local position = _touchLayer:convertToWorldSpace(cc.p(_x,_y))--世界坐标转换
    local _size=_node:getContentSize()
    local _bool=inside(position.x,position.y,_size.width,_size.height,math.ceil(px),math.ceil(py))
    return _bool
end
local function getPointNode(px,py)--获取触摸元素
    -- body
    for i,v in ipairs(_nodes) do
        local _temp_node
    if insideNode(v,px,py) then
      _temp_node=v:clone()
      _touchLayer:addChild(_temp_node)
     return _temp_node
    end 
    end
    return nil
end

function tuozhuaiLayer:onEnter()
   
end

function tuozhuaiLayer:onExit()
end

function tuozhuaiLayer.create()
    local scene = tuozhuaiLayer.new()
    scene:addChild(scene:createLayer())
    return scene
end
local function add_question_tg (_H,_tables,size)
    -- body
    local _text=RichText(_H,_tables,size)
    _text:setAnchorPoint(cc.p(0,1))
    _text:setPosition(0,150)
    _touchLayer:getChildByName('Panel'):addChild(_text)

end
function tuozhuaiLayer:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("test_0.csb")
    self._uilayer:setPosition(cc.p(0,0))
    _touchLayer=self._uilayer:getChildByName('FileNode_1')
    add_question_tg(150,_content,30)
    -- print('len----'..#_actions)
    -- for i,v in ipairs(_actions) do
    --     local _x,_y=v:getPosition()
    -- print('_x===..'.._x)
    -- print('_y===..'.._y)
    -- local _wpoint=_node:convertToWorldSpace(cc.p(_x,_y))
    -- print('x==='.._wpoint.x)
    -- print('y==='.._wpoint.y)
    -- end
    
    for i=1,3 do
    local _node=_touchLayer:getChildByName('Panel_'..i)
    table.insert(_nodes,_node)
    end
        local function onTouchBegan(touch, event)
            local location = touch:getLocation()
            print("onTouchBegan: %0.2f, %0.2f", location.x, location.y)
            _curItem=getPointNode(location.x,location.y,nil)
            return true
        end
        local function onTouchMoved(touch, event)
            local location = touch:getLocation()
            local x=math.ceil(location.x)
            local y=math.ceil(location.y)
            local _point=_touchLayer:convertToNodeSpace(cc.p(x,y))
            if _curItem~=nil then 
            _curItem:setPosition(_point)
            end 
            print("onTouchMoved: %0.2f, %0.2f", location.x, location.y)
        end

        local function onTouchEnded(touch, event)
            local location = touch:getLocation()
            local x=math.ceil(location.x)
            local y=math.ceil(location.y)
            print('tag----->'.._curItem:getTag())
            _curItem:removeFromParentAndCleanup(true)
            _curItem=nil

            print("onTouchEnded: %0.2f, %0.2f", location.x, location.y)
            
        end

        local listener = cc.EventListenerTouchOneByOne:create()
        listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
        listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
        listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
        local eventDispatcher = _touchLayer:getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(listener, _touchLayer)
    return self._uilayer
end
function tuozhuaiLayerCreate()
    return tuozhuaiLayer.create()
end



