--知识点章节
local zhishidianPage = class("zhishidianPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
zhishidianPage.__index = zhishidianPage
zhishidianPage._uilayer = nil
function zhishidianPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function zhishidianPage:onEnter()
   
end

function zhishidianPage:onExit()
end

function zhishidianPage.create()
    local scene = zhishidianPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function zhishidianPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("zsdzhangjie.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    return self._uilayer
end
function zhishidianPage:initButton()
    -- body
require "control" 
    local ButtonBack=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
   ButtonBack:addClickEventListener(function() goUI(_allUI.mainPage) end)--返回主页
   local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
   _name:setString(_title)
   self:initList()
end
function zhishidianPage:initList()--初始化list列表
    -- body
    local _listView=self._uilayer:getChildByName('ListView')
    local _node=self._uilayer:getChildByName('item_node')
    local _item=_node:getChildByName('item_node')
    print('_knowledgeList------>'..#_knowledgeList)
    for i = 1, #_knowledgeList do
        local _temp=_knowledgeList[i]


        local knowledgepointname=_temp['knowledgepointname']
        print('knowledgepointname----------------------'..knowledgepointname)
        local questionType=_temp['questiontype']
        local _tmList=_temp['coursewaredetail'] or {}
        local _subjectName=_temp['subjectName']
        
        print('questionType---------->'..questionType)
        local examLevel=_temp['examlevel']
        local courseId=_temp['courseid']
        local knowledgeId=_temp['knowledgepointid']
        for i,v in ipairs(_tmList) do
         local _tmnum=_temp['tmnum']
         local _videourl=_temp['videourl']
         local _items = _item:clone();
         local _name=_items:getChildByName('name')
         _name:setString(knowledgepointname)
         local _img=_items:getChildByName('Image')
         local _button_kj=_items:getChildByName('Button_kj')
         local _button_lx=_items:getChildByName('Button_lx')
         _button_lx:addClickEventListener(function ( ... )
             -- body
                get_questionList(questionType,examLevel,courseId,knowledgeId,function ( code,data )
                 -- body
                 if code==200 then 
                 print("知识点-----"..data)
                 require "control" goUI(_allUI.myLianXiPage)
                 end
                end)
         end)
        _listView:pushBackCustomItem(_items);
        end
        
    end
end
function zhishidianPageCreate()
    return zhishidianPage.create()
end



