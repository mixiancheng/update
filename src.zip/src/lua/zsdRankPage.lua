--知识点排名
local zsdRankPage = class("zsdRankPage",function()
    return cc.Scene:create()
end)
-- local sa = require "screenAdaption"
zsdRankPage.__index = zsdRankPage
zsdRankPage._uilayer = nil
function zsdRankPage:ctor()
    local function sceneEventHandler(eventType)
        if eventType == "enter" then
            self:onEnter()
        elseif eventType == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(sceneEventHandler)
end

function zsdRankPage:onEnter()
   
end

function zsdRankPage:onExit()
end

function zsdRankPage.create()
    local scene = zsdRankPage.new()
    scene:addChild(scene:createLayer())
    return scene
end

function zsdRankPage:createLayer( ... )
    self._uilayer = cc.CSLoader:createNode("zsdpaimingList.csb")
    self._uilayer:setPosition(cc.p(0,0))
    self:initButton()
    self:initList()
    return self._uilayer
end
function zsdRankPage:initButton()
    -- body
print('title----'.._title)
    local ButtonBack=self._uilayer:getChildByName('FileNode_back'):getChildByName('Button_back')
   ButtonBack:addClickEventListener(function() 
    require 'control' goUI(_SceneInfo_old)
--     if _title=='知识点排名' then  
--         print('知识点排名')
--         goUI(_allUI.fenxizhongxinPage) 
-- return
--          end
--     if _title=="分析中心"  then  print('分析中心') 
--      goUI(_allUI.mainPage)
--      return
--       end
   end)--返回主页
   local _name=self._uilayer:getChildByName('FileNode_back'):getChildByName('name')
   _name:setString(_title)
end
function zsdRankPage:initList()--初始化list列表
    -- body
    local _img_zsd=self._uilayer:getChildByName('Image_zsd')
    local _listView=self._uilayer:getChildByName('ListView')
    local _node=self._uilayer:getChildByName('item_node')
    local _item=_node:getChildByName('item_node')
    for i = 1, #_knowledgeRankList do
        local _temp=_knowledgeRankList[i]
        local knowledgepointname=_temp['knowledgepointname']
        local knowledgepointrank=_temp['knowledgepointrank']
        local knowledgepointid=_temp['knowledgepointid']
        local knowledgepointaccuracy=_temp['knowledgepointaccuracy']
         local _items = _item:clone();
         local _name=_items:getChildByName('name')
         _name:setString(knowledgepointname)
         local _score=_items:getChildByName('score')
         _score:setString(knowledgepointaccuracy)
         local _rank=_items:getChildByName('rank')
         _rank:setString(knowledgepointrank)
         local _button_rank=_items:getChildByName('Button_rank')
         _button_rank:setVisible(false)
        _listView:pushBackCustomItem(_items);
    end
end
function zsdRankPageCreate()
    return zsdRankPage.create()
end



