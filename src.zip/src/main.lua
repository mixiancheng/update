
cc.FileUtils:getInstance():setPopupNotify(false)

require "config"
require "cocos.init"
require("json")
-- function myHtttps( _url,_table,_post,_fun,_Session )
--     print("-------------------{myHtttps--------------------")
-- --    _Session="81qitwlj3l60ljcs2c8ts9k8r"
--     print("myHtttps--url==".._url)
--     print("myHtttps--POST==".._post)
--     if _table~=nil then
--         local _requireJson=json.encode(_table)
--         print("myHtttps--Json==".._requireJson)
--     end
--     -- body
--     local xhr = cc.XMLHttpRequest:new()
--     xhr.timeout=1
--     xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_JSON
--     xhr:setRequestHeader("Content-Type",'application/json')
--     xhr:open(_post,_url)
--     local function onReadyStateChange()
--         print("-------------------{myHtttpsCallBack--------------------")
--         print("myHtttps-->code=="..xhr.status)
--         if xhr.status==200 or xhr.status==201 then
--         print("myHtttps-->json=="..xhr.response)
--         end
--         _fun(xhr.status,xhr.response)
--         print("-------------------myHtttpsCallBack}--------------------")
--     end
--     xhr:registerScriptHandler(onReadyStateChange)
--     local jsonDate=json.encode(_table)
--         xhr:send(jsonDate)
--     print("-------------------myHtttps}--------------------")
-- end
local function main()
    print("运行了程序")
    RES_TESTURE_TYPE=0

    local director = cc.Director:getInstance()
    local glView   = director:getOpenGLView()
    print("caks"..glView:getFrameSize().height)


local sHeight = cc.Director:getInstance():getVisibleSize().height
local sWidth = cc.Director:getInstance():getVisibleSize().width

    print("visibleSize高度和宽度"..sHeight..sWidth)

    if nil == glView then
        print("8989")
        glView = cc.GLView:createWithRect("Lua Tests", cc.rect(0,0,1536,2048))
        director:setOpenGLView(glView)
    end

    --turn on display FPS
    -- director:setDisplayStats(true)
    director:setDisplayStats(false)

    --set FPS. the default value is 1.0/60 if you don't call this
    director:setAnimationInterval(1.0 / 60)
    screenSize = glView:getFrameSize()
    print("frameSize高度和宽度"..screenSize.height..screenSize.width)
    -- EXACT_FIT = 0,
    -- NO_BORDER = 1,
    -- SHOW_ALL  = 2,
    -- FIXED_HEIGHT  = 3,
    -- FIXED_WIDTH  = 4,
    -- UNKNOWN  = 5,
    --local _scale=_h/_w
    local designSize = {width = 768, height = 1024}
    -- glView:setDesignResolutionSize(designSize.width, designSize.height, cc.ResolutionPolicy.SHOW_ALL)
    glView:setDesignResolutionSize(designSize.width, designSize.height, cc.ResolutionPolicy.EXACT_FIT)
    cc.FileUtils:getInstance():addSearchPath("src")
    cc.FileUtils:getInstance():addSearchPath("src/cocosUi")
    cc.FileUtils:getInstance():addSearchPath("src/lua")
    cc.FileUtils:getInstance():addSearchPath("src/accountLogin")
    cc.FileUtils:getInstance():addSearchPath("src/accountLogin/publish")
    cc.FileUtils:getInstance():addSearchPath("src/courseCoverSc")
    cc.FileUtils:getInstance():addSearchPath("src/courseCoverSc/publish")
    cc.FileUtils:getInstance():addSearchPath("src/homeSc")
    cc.FileUtils:getInstance():addSearchPath("src/homeSc/publish")
    cc.FileUtils:getInstance():addSearchPath("src/loginSc")
    cc.FileUtils:getInstance():addSearchPath("src/loginSc/publish")
    cc.FileUtils:getInstance():addSearchPath("src/pkSc")
    cc.FileUtils:getInstance():addSearchPath("src/pkSc/publish")
    cc.FileUtils:getInstance():addSearchPath("src/rankSc")
    cc.FileUtils:getInstance():addSearchPath("src/rankSc/publish")
    cc.FileUtils:getInstance():addSearchPath("src/selectPetSc")
    cc.FileUtils:getInstance():addSearchPath("src/selectPetSc/publish")
    cc.FileUtils:getInstance():addSearchPath("src/selectPetSc/publish/Demo1")
    cc.FileUtils:getInstance():addSearchPath("src/startSc")
    cc.FileUtils:getInstance():addSearchPath("src/startSc/publish")
    cc.FileUtils:getInstance():addSearchPath("src/until")


    require "control"
    require 'img'
--     require  "mime"   
-- --Base64编码  
-- local base64Str = mime.b64( "寒江孤叶丶的Cocos2d-x之旅" )  
-- print(base64Str)  
  
-- --Base64解码  
-- local unBase64Str = mime.unb64(base64Str)  
-- print(unBase64Str) 
    -- { "requestSystemName": "Android客户端",
    --  "requestSystemID": "1", 
    --  "requestSystemDate": "2017:-06-21 11:24:24",
    --   "requestSystemTime": " 11:24:24",
    --    "userName": "18810357686", 
    --    "passWord": "123456" }
    -- goUI(_allUI.selectPetSc)
    -- goUI(_allUI.recognitionFaceSc)
    -- goUI(_allUI.recognitionNameSc)
    -- goUI(_allUI.homeSc)
    --goUI(_allUI.accountLoginSc)
    -- goUI(_allUI.logoPage)
    -- local _img=''
    -- _img['name']='imgName.png'
    -- _img['url']='imgUrl'
    -- local _edi=''
    -- local _node=''
    -- _node['type']='_str'-- _str字符串  _img 图片  _edi=填空
    -- _node['value']="adadasdsdsd" -- 'dadasdasd'--文本  _imgName图片名称／URL   _deiLen空格长度
    -- local content={}
    -- table.insert(content,{type='_str',value='____ that girl?'})
    -- table.insert(content,{type='_img',value='imgName.png',url='imgUrl'})
    -- table.insert(content,{type='_edi',value=10})
    -- local _str=json.encode(content)
    -- print('_str----->'.._str)
    -- local result={}
    -- table.insert(result,{type='_str',value='A.adadadasdasda'})
    -- table.insert(result,{type='_str',value='B.adadadasdasda',isResule='true'})
    -- table.insert(result,{type='_str',value='C.adadadasdasda'})
    -- table.insert(result,{type='_img',value='imgName.png',url='imgUrl'})
    -- local _str_r=json.encode(result)
    -- print('result---->'.._str_r)
    -- "result"="tom"
    -- goUI(_allUI.testPage)
    -- get_testList(function ( ... )
    --     -- body
    -- end)

-- require "myTime"
--     myTime.set_time(100,nil)
--     myTime.get_time_result()
-- local _test={}
-- _test[1]="dasda"
-- _test[3]='adasdasd'
-- for i,v in ipairs(_test) do
--     print(i,v)
-- end
    -- goUI(_allUI.kdTest)
    -- require 'modelData'
    -- print (_modelData.requestSystemName)
    goUI(_allUI.logoPage)
    -- goUI(_allUI.linePage)
    -- goUI(_allUI.tuozhuaiLayer)

    -- local _data={}
    -- _data['requestSystemName']="Android客户端"
    -- _data['requestSystemID']="1"
    -- _data['requestSystemDate']="2017:-06-21 11:24:24"
    -- _data['requestSystemTime']="11:24:24"
    -- _data['userName']="18810357686"
    -- _data['passWord']="123456"
    -- myHtttps("http://mp.ssyunschool.com/login/login.do",_data,"POST",function ( state,data)
    -- 	-- body
    -- end)

    --课表
    -- local _data_arrang={}
    -- _data_arrang['requestSystemName']='Android 客户端'
    -- _data_arrang['requestSystemID']='1'
    -- _data_arrang['requestSystemDate']='2017:-06-21 11:24:24'
    -- _data_arrang['requestSystemTime']='11:24:24'
    -- -- _data_arrang['token']='d2d3beb8-91fc-4e0f-91fe-da3958540242'
    -- _data_arrang['token']='6d2cf3fa-57e8-4ca4-badb-38861f52ce83'
    -- myHtttps("http://mp.ssyunschool.com/schedule/arranging.do",_data_arrang,"POST",function ( state,data)
    --     -- body
    -- end)
    -- myHtttps("http://www.baidu.com",nil,"GET",function ( state,data)
    --     -- body
    -- end)

end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end
