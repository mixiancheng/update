--
-- require "luaunit"
module ("Plugin",package.seeall)

function createEditBox(_root,config_T)
    local Pos = config_T.Pos or cc.p(10,2)
    local FontColor = config_T.FontColor or cc.c3b(6,66,61)
    local FontSize = config_T.FontSize or cc.c3b(6,66,61)
    local PlaceholderFontSize = config_T.PlaceholderFontSize or 27
    local PlaceholderFontColor = config_T.PlaceholderFontColor or 27
    local nodeColor = config_T.color

    local FontName = config_T.FontName or "fonts/simhei.ttf"
    local Placeholder = config_T.Placeholder
    -- assertNotNil(Placeholder)
    local _len = config_T.MaxLength
    -- assertNotNil(_len)
    local editBoxSize = config_T.editBoxSize or cc.size(280, 48)
    require "jz_config"
    local callback = config_T.callback or jz_config.get_event()
    local EditEmail =
        ccui.EditBox:create(editBoxSize, "dianjiu.png",RES_TESTURE_TYPE)
    EditEmail:setPosition(Pos)
    EditEmail:setAnchorPoint(cc.p(0,0))
    EditEmail:setFontColor(FontColor)
    EditEmail:setFont(FontName,FontSize)
    if nodeColor ~= nil then
        EditEmail:setColor(nodeColor)
    end
    if cc.Application:getInstance():getTargetPlatform()~= cc.PLATFORM_OS_ANDROID then
        EditEmail:setPlaceholderFont(FontName,PlaceholderFontSize)
    end
    EditEmail:setPlaceHolder(Placeholder)
    EditEmail:setPlaceholderFontColor(PlaceholderFontColor)
    EditEmail:setMaxLength(_len)
    EditEmail:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE )
    EditEmail:setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE)
    EditEmail:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
    EditEmail:registerScriptEditBoxHandler(function(strEventName,pSender)
            local _str=pSender:getText()
            require "jz_config"
            local _table=jz_config.change(_str)
            local _final=""
            for k,v in ipairs(_table) do
                local _num=string.byte(v,1,string.len(v))
            if _num~=32 and _num~=226 then
                    _final=_final..v
                end
            end
            if strEventName == "ended" or strEventName == "return" then
                pSender:setText(_final)
            end
            -- todo
        end)
    _root:addChild(EditEmail,1)
    return EditEmail
end





