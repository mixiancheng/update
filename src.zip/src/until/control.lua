require "logo"
require "login"
require "mainPage"
require "recordPage"
require "selfInfoPage"
require "testListPage"
require "zhishidianPage"
require "fenxizhongxinPage"
require "testPage"
require 'cuotiSc'
require 'lianxiPage'
require 'test_ls'
require 'scoreSc'
require 'zsdRankPage'
require 'baogaoPage'
require 'lineSc'
require 'tuozhuaiLayer'
require 'kdTest'
require 'myAnswerPage'
require 'myLianXiPage'
require 'myHomeworkListPage'
print("require---------------------------------------")
-- _curSceneName=''--当前页面
-- _oldSceneName=''--页面记录
-- _paperType='3'--试卷类型 （练习--1，知识点--2，测试--3）
-- _questionType='1'--知识点-1，课后作业-2，易错题-3， 我的错题-4，标记试题-5
-- _paperLevel='1'--试卷等级
-- _currentPage='1'--页面
-- _knowledgeId=''--知识点id
-- _userLevel=""--用户等级
-- _courseId=''--课程id
-- _examlevel=''
-- local _url='http://mp.ssyunschool.com/indexService/'
local _url='http://mp.ssyunschool.com/'
_title=''
_studentId=''
_paper_kaoshi_result=''
_paperParts=''
_examCode=''
_SceneInfo_old='' 
_SceneInfo_new=''
_questionDetail=''
_paperDetail=''
_knowledgeList=''
_recordsDetail=''
_properInfoDetail=''
_kebiao_data=''
_token=cc.UserDefault:getInstance():getStringForKey('_token')--token
_allUI={--ui控制
kdTest={title="",name = "linePage",crt_fun = kdTestCreate},--连线
linePage = {title="",name = "linePage",crt_fun = lineScCreate},--连线
tuozhuaiLayer={title="",name = "tuozhuaiLayer",crt_fun = tuozhuaiLayerCreate},--拖拽
    logoPage = {title="",name = "logoPage",crt_fun = logoPageCreate},--启动页
    loginPage = {title="",name = "loginPage",crt_fun = loginPageCreate},--登陆页面
    scorePage = {title="",name = "scorePage",crt_fun = scoreScCreate},--成绩页面
    baogaoPage = {title="测评报告",name = "baogaoPage",crt_fun = baogaoPageCreate},--测评报告页面
    mainPage = {title="",name = "mainPage",crt_fun = mainPageCreate},--主页
    testPage = {title="考试",name = "testPage",crt_fun = testPageCreate},--测试页面
    myAnswerPage = {title="查看答案",name = "myAnswerPage",crt_fun = myAnswerPageCreate},--查看答案
    test_lsPage = {title="练习",name = "test_lsPage",crt_fun = test_lsCreate},--测试练习页面
    selfInfoPage = {title="我的课表",name = "selfInfoPage",crt_fun = selfInfoPageCreate},--个人中心
    zhishidianPage = {title="知识章节",name = "zhishidianPage",crt_fun = zhishidianPageCreate},--知识点章节页面
    wodecuotiPage = {title="错题",name = "cuotiPage",crt_fun = cuotiPageCreate},--错题 知识点章节页面
    lianxiPage = {title="练习题",name = "lianxiPage",crt_fun = lianxiPageCreate},--练习 知识点章节页面：进入考试页面
    myLianXiPage = {title="练习题",name = "myLianXiPage",crt_fun = myLianXiPageCreate},--练习试题页面
    testListPage = {title="测试",name = "testListPage",crt_fun = testListPageCreate},--测试列表页面
    -- yicuotiPage = {title="易错题",name = "yicuotiPage",crt_fun = testListPageCreate},--易错题  测试页面
    recordPage = {title="我的记录",name = "recordPage",crt_fun = recordPageCreate},--记录
    kehouzuoyePage = {title="课后作业",name = "myHomeworkListPage",crt_fun = myHomeworkListPageCreate},--课后作业：进入考试页面
    zsdpaimingPage = {title="知识点排名",name = "zsdpaimingPage",crt_fun = zsdRankPageCreate},--知识点排名 
    fxzxPage = {title="分析中心",name = "fenxizhongxinPagePage",crt_fun = fxzxPageCreate}
    -- 分心中心页面
}
local function get_header_table()--基础表头
    -- body
    local _data={}
    _data['requestSystemName']="Ios客户端"
    _data['requestSystemID']="1"
    _data['requestSystemDate']=os.date("%Y-%m-%d %H:%M:%S")
    _data['requestSystemTime']=os.date("%H:%M:%S")
    return _data
end
function goUI(_SceneInfo)
    -- _oldSceneName=_curSceneName
    -- if _SceneInfo_old=='' then  _SceneInfo_old=_SceneInfo
    -- else
    --  _SceneInfo_old=_SceneInfo_new
    --  _SceneInfo_new=_SceneInfo
    -- end 
    _curSceneName=_SceneInfo.name
    _title=_SceneInfo.title
    if _SceneInfo.parm ~= nil then
        _curScene=_SceneInfo.crt_fun(_SceneInfo.parm)
    else
        _curScene=_SceneInfo.crt_fun()
    end
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(_curScene)
    else
        cc.Director:getInstance():runWithScene(_curScene)
    end

    if _SceneInfo_old=='' then  _SceneInfo_old=_SceneInfo
    else
     _SceneInfo_old=_SceneInfo_new
     _SceneInfo_new=_SceneInfo
    end
end
function goUIBack()
    -- body
end
function myHtttps( _url,_table,_post,_fun,_Session )
    print("-------------------{myHtttps--------------------")
--    _Session="81qitwlj3l60ljcs2c8ts9k8r"
    print("myHtttps--url==".._url)
    if _table~=nil then
        local _requireJson=json.encode(_table)
        print("myHtttps--JsonCall==".._requireJson)
    end
    -- body
    local xhr = cc.XMLHttpRequest:new()
    xhr.timeout=1
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_JSON
    xhr:setRequestHeader("Content-Type",'application/json')
    xhr:open(_post,_url)
    local function onReadyStateChange()
        print("-------------------{myHtttpsCallBack--------------------")

        -- print('xhr.response--'..xhr.response)
        if xhr.status==200 or xhr.status==201 then 
            local _temp=json.decode(xhr.response)
            if _temp['returnCode']=='0000' then 
            _fun(xhr.status,xhr.response)
            end 
        end
        print("-------------------myHtttpsCallBack}--------------------")
    end
    xhr:registerScriptHandler(onReadyStateChange)
    local jsonDate=json.encode(_table)
        xhr:send(jsonDate)
    print("-------------------myHtttps}--------------------")
end

---------------------------------登陆---------------------------------
function login(_userName,_passWord,_fun )
    -- body
    print('-------------------登陆---------------------')
    local _data=get_header_table()
    _data['userName']=_userName
    _data['passWord']=_passWord
    _data['passWord']=_passWord
    myHtttps(_url.."login/login.do",_data,"POST",function ( code,data)
    require("json")
     if code==200 then
       local _table=json.decode(data)
       print('data---->'..data)
        _token=_table.token
       cc.UserDefault:getInstance():setStringForKey('_token',_token);
       cc.UserDefault:getInstance():flush()
     end
     _fun(code,data)
    end)
    print('-------------------登陆---------------------')
end
-------------------------------试卷列表---------------------------------

function get_testList(_paperType,_currentPage,_fun )
    -- body
    print('-------------------试卷列表---------------------')
    local _data=get_header_table()
    _data['token']=_token
    _data['paperType']=_paperType
    _data['currentPage']=_currentPage
    myHtttps(_url.."exam/examPaper.do",_data,"POST",function ( code,data)
        -- body
        if code==200 then  
            path = cc.FileUtils:getInstance():getWritablePath()
    local f = io.open(path..'examPaper.txt', "w+")
    f:write(data);
    f:close();
        _paperDetail=json.decode(data).paperDetail or _paperDetail
        -- print('len------>'..#_paperDetail)
         end
        _fun(code,data)
    end)
    print('-------------------试卷列表---------------------')
end
--------------------------我的考试-------------------------------
local _myAnswer=''
function myAnswer( examCode,studentId,_fun )
    -- body
    _studentId=studentId
    local _data=get_header_table()
    _data['token']=_token
    _data['examCode']=examCode
    _data['studentId']=_studentId
    myHtttps(_url.."exam/myAnswer.do",_data,"POST",function ( code,data)
        -- body
        -- print('data'..data)
        if code==200 then 
        _examCode=examCode             
        _paperParts=json.decode(data) or _paperParts
        _studentId=_paperParts.studentId
    --     path = cc.FileUtils:getInstance():getWritablePath()
    -- local f = io.open(path..'myAnswer.txt', "w+")
    -- f:write(data);
    -- f:close();

        ----debug
        -- require 'dataModel'
        -- _paperParts=get_model()
        -- print('data------'..data)
        print('returnMessage---------->'.._paperParts.returnMessage)
         end
        _fun(code,data)
    end)
    print('-------------------我的答案---------------------')
end
function kaoshi( examCode,studentId,_fun )
    -- body
    
    local _data=get_header_table()
    _data['token']=_token
    _data['examCode']=examCode
    _data['studentId']=studentId
    myHtttps(_url.."exam/ksMyExam.do",_data,"POST",function ( code,data)
        -- body
        print('data-------'..data)
        if code==200 then 
        _examCode=examCode             
        _paperParts=json.decode(data) or _paperParts
        _studentId=_paperParts.studentId
        print('returnMessage---------->'.._paperParts.returnMessage)
         end
        _fun(code,data)
    end)
    print('-------------------试卷---------------------')
end
function ksSubmitPaperOne(_questionID,_questionType,_timeLong,_answer,_fun)
    -- body
    local _data=get_header_table()
    _data['token']=_token
    -- _data['examCode']=_examCode--缓存
    _data['examCode']=''--缓存
    _data['studentId']=_studentId--缓存
    _data['questionID']=_questionID
    _data['questionType']=_questionType
    _data['timeLong']=_timeLong
    _data['answer']=_answer
    myHtttps(_url.."exam/ksSubmitPaperOne.do",_data,"POST",function ( code,data)
        -- body
        if code==200 then  
        print("ksSubmitPaperOne-----"..data)            
        local _data_back=json.decode(data)
        print('returnMessage---------->'.._data_back.returnMessage)
        _fun(code,data)
         end
    end)
end
function submitPaper(_answer_table,_fun )
    -- body
    for i,v in ipairs(_answer_table) do
        print('questionID=='..v['questionID'])
    end
    local _data=get_header_table()
    _data['token']=_token
    _data['examCode']=_examCode
    _data['studentId']=_studentId--缓存
    local _temp=_answer_table
    for i,v in ipairs(_answer_table) do
        for h,j in ipairs(v.answer) do
            if j['result']==1 then v.answer[h]['result']='A' end 
            if j['result']==2 then v.answer[h]['result']='B' end 
            if j['result']==3 then v.answer[h]['result']='C' end 
            if j['result']==4 then v.answer[h]['result']='D' end 
        end
    end
    _data['answers']=_answer_table
    -- local _Str=json.encode(_data)
    -- print('_str-----'.._Str)
    myHtttps(_url.."exam/ksSubmitPaperAll.do",_data,"POST",function ( code,data)
        -- body
        if code==200 then              
        local _data_back=json.decode(data)
        _paper_kaoshi_result=''
        _paper_kaoshi_result=_data_back.result
        print('returnMessage---------->'..data)
        print('returnMessage---------->'.._data_back.returnMessage)
         end
        _fun(code,data)
    end)
    print('-------------------提交答案---------------------')
end
--------------------------我的考试-------------------------------
-------------------------------获取试卷---------------------------------

function get_questionList(_questionType,_userLevel,_courseId,_knowledgeId,_fun )
    -- body
    print('-------------------试卷---------------------')
    print(''.._questionType)
     print(''.._userLevel)
      print(''.._courseId)
       print(''.._knowledgeId)

    local _data=get_header_table()
    _data['token']=_token
    _data['questionType']=_questionType--知识点-1，课后作业-2，易错题-3， 我的错题-4，标记试题-5
    _data['userLevel']=_userLevel--用户级别
    _data['courseId']=_courseId--课表 ID,为空表示此级别下所有排课 试题都可以做
    _data['knowledgeId']=_knowledgeId--知识点 ID,为空表示此级别下的所有 知识点
    _data['parameterCode']='1'
    myHtttps(_url.."exam/questionList.do",_data,"POST",function ( code,data)
        -- body
        if code==200 then  
        -- print("")
        _paperParts=json.decode(data) or _paperParts
        _studentId=_paperParts["studentId"]
        -- print('len------>'..#_paperDetail)
         end
        _fun(code,data)
    end)
    print('-------------------试卷---------------------')
end
-------------------------------获取试卷---------------------------------
-------------------------------知识点-----------------------------------

function get_zhishidian( _fun )
    -- body
    print('-------------------知识点---------------------')
    local _data=get_header_table()
    _data['token']=_token
    myHtttps(_url.."exam/myKnowledge.do",_data,"POST",function ( code,data)
        -- body
        if code==200 then  _knowledgeList=json.decode(data).paperDetail or _knowledgeList end
        if _knowledgeList==nil then _knowledgeList="" end 
        _fun(code,data)
    end)
    print('-------------------知识点---------------------')
end
---------------------------------我的记录----------------------------------
----------------------------------知识点排名
_knowledgeRankList=''
function get_zhishidianRank(_examCode,_studentid,_fun)
    -- body
    print('-------------------知识点排名---------------------')
    local _data=get_header_table()
    _data['token']=_token
    _data['examCode']=_examCode
    _data['studentId']=_studentId
    myHtttps(_url.."exam/knowledge.do",_data,"POST",function ( code,data)
        -- body
        print('data===='..data)
        if code==200 then  _knowledgeRankList=json.decode(data).paperDetail or _knowledgeRankList end
        if _knowledgeRankList==nil then _knowledgeRankList="" end 
        _fun(code,data)
    end)
    print('-------------------知识点排名---------------------')
end
------------------------------------------------知识点排名
-- for i=1,10 do
--     print(i)
-- end

function get_myRecord( _fun )
    -- body
    print('-------------------记录---------------------')
    local _data=get_header_table()
    _data['token']=_token
    myHtttps(_url.."exam/myRecord.do",_data,"POST",function ( code,data)
        -- body
        if code==200 then   _recordsDetail=json.decode(data).recordsDetail or _recordsDetail end
        if _recordsDetail==nil then _recordsDetail="" end 
        _fun(code,data)
    end)
    print('-------------------纪录---------------------')
end
-----------------------------------错题-------------------------------
_questionDetails=''
function get_cuotiList( _fun )
    -- body
    print('-------------------错题---------------------')
    local _data=get_header_table()
    _data['token']=_token
    _data['examCode']=''
    myHtttps(_url.."exam/myMistakes.do",_data,"POST",function ( code,data)
        -- body
        print('get_cuotiList----->'..data)
        if code==200 then   _questionDetails=json.decode(data).questionDetails or _questionDetails end
        if _questionDetails==nil then _questionDetails="" end 
        _fun(code,data)
    end)
    print('-------------------错题---------------------')
end
-------------------------------分析中心--------------------------------
_analysisCenter=''
function analysisCenter( _examCode,_fun )
    -- body
    print('-------------------分析中心---------------------'.._examCode..":".._studentId)
    local _data=get_header_table()
    _data['token']=_token
    _data['examCode']=_examCode
    _data['studentId']=_studentId
    myHtttps(_url.."exam/analysisCenter.do",_data,"POST",function ( code,data)
        -- body
        print('_analysisCenter----'..data)
        if code==200 then   _analysisCenter=json.decode(data).paperDetail or _analysisCenter end
        if _analysisCenter==nil then _analysisCenter="" end 
        _fun(code,data)
    end)
    print('-------------------分心中心---------------------')
end
-------------------------------测试报告--------------------------------

function get_baogao( examCode,studentId,_fun )
    -- body
    print('-------------------测试报告---------------------')
    local _data=get_header_table()
    _data['token']=_token
    _data['examCode']=examCode
    _data['studentId']=studentId
    myHtttps(_url.."exam/testReport.do",_data,"POST",function ( code,data)
        -- body
        print('properInfoDetail----'..data)
        if code==200 then   _properInfoDetail=json.decode(data) or _properInfoDetail end
        if _properInfoDetail==nil then _properInfoDetail="" end 
        _fun(code,data)
    end)
    print('-------------------测试报告---------------------')
end
-------------------------------测试报告--------------------------------
-------------------------------获取课表--------------------------------

function get_kebiao_date(_fun)--获取课表
    -- body
    print('-------------------课表---------------------')
    local _data=get_header_table()
    _data['token']=_token
    myHtttps(_url.."schedule/arranging.do",_data,"POST",function ( code,data)
        -- body
        if code==200 then  _kebiao_data=json.decode(data).arranging or _kebiao_data end
        _fun(code,data)
    end)
    print('-------------------课表---------------------')
end
function dellEditBox( ... )
  -- body
  local luaoc = require "cocos.cocos2d.luaoc"
            -- local luaoc = require "luaoc"
            local className = "RootViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"dellEditBox",nil)
            if not ok then
                print("The ret is:NO")
                -- Director:getInstance():resume()
            else
                print("The ret is:", ret)
            end
end
function addEditBox( _mes,_fun )
  -- body
  local luaoc = require "cocos.cocos2d.luaoc"
            -- local luaoc = require "luaoc"
            local args = { _str = _mes,_fun=_fun}
            local className = "RootViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"showEditBox",args)
            if not ok then
                print("The ret is:NO")
                -- Director:getInstance():resume()
            else
                print("The ret is:", ret)
            end
end
function login_out_data(  )
    -- body
_title=''
_studentId=''
_paper_kaoshi_result=''
_paperParts=''
_examCode=''
_SceneInfo_old='' 
_SceneInfo_new=''
_questionDetail=''
_paperDetail=''
_knowledgeList=''
_recordsDetail=''
_properInfoDetail=''
_kebiao_data=''
_token=''
cc.UserDefault:getInstance():setStringForKey('_token',_token);
cc.UserDefault:getInstance():flush()
goUI(_allUI.loginPage)
end