module("jz_config",package.seeall)
child_name_len=6
email_len=30
phone_len=11
login_name=10
login_pass=8
FontColor=cc.c3b(255,255,255)
PlaceholderFontColor=cc.c3b(96,96,96)
local function utf8len(input,limitCharByteCount)
    local len = string.len(input) -- 获取字节数 （注：在 UTF-8 编码里，一个汉字通常占 3 个字节，在 GBK 里一个中文得到2）
    local left = len
    local cnt = 0
    local bl_out_limit = false
    local arr = {0,0xc0,0xe0,0xf0,0xf8,0xfc} --utf8可变字节特性 0000 0000，1100 0000，1110 0000，1111 0000，1111 1000，1111 1100
    while left ~= 0 do
        local tmp = string.byte(input,-left)
        local i = #arr
        while arr[i] do
            if tmp >= arr[i] then
                left = left - 1
                break
            end
            i = i - 1
        end
        if i > (limitCharByteCount or 3) then --大部分需要的字符都集中在3字节内,包括中文,超过3字节就直接过滤
            bl_out_limit = true
        end
        cnt = cnt + 1
    end
    return cnt,bl_out_limit
end
local function filterChar(str,fliterLimitCharCount,filterFormat,defaultChangeStr)
    local utf8_len,bl_out_limit = utf8len(str,fliterLimitCharCount)
    if bl_out_limit then
        return defaultChangeStr or ""
    end
    local newlen,newstr = 0,""
    --default to filter the emoji
    for unchar in string.gfind(str,filterFormat or "[%z\48-\57\64-\126\226-\233][\128-\191]*") do
        newstr = newstr .. unchar
--        k_len = k_len + 1
    end
--    if len ~= newlen then
--        newstr = defaultChangeStr or "" --不管需要过滤的特殊字符被如何转码,长度不匹配直接过滤,若长度正巧匹配使用拼接后的新字符串,特殊字符会被转为无意义的乱码
--    end
    return newstr
end
function Utf8to32(utf8str)
    assert(type(utf8str) == "string")
    local res, seq, val = {}, 0, nil
    for i = 1, #utf8str do
        local c = string.byte(utf8str, i)
        if seq == 0 then
            table.insert(res, val)
            seq = c < 0x80 and 1 or c < 0xE0 and 2 or c < 0xF0 and 3 or
                c < 0xF8 and 4 or --c < 0xFC and 5 or c < 0xFE and 6 or
                error("invalid UTF-8 character sequence")
            val = bit32.band(c, 2^(8-seq) - 1)
        else
            val = bit32.bor(bit32.lshift(val, 6), bit32.band(c, 0x3F))
        end
        seq = seq - 1
    end
    table.insert(res, val)
    table.insert(res, 0)
    return res
end
----------------------------
function change ( str )
--    local _table=Utf8to32(str)
--    table_out("Utf8to32",_table)
    local len  = #str
    local left = 0
    local arr  = {0, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc}
    local t = {}
    local start = 1
    local wordLen = 0
    while len ~= left do
        local tmp = string.byte(str, start)
        local i   = #arr
        while arr[i] do
            if tmp >= arr[i] then
                break
            end
            i = i - 1
        end
        wordLen = i + wordLen
        local tmpString = string.sub(str, start, wordLen)
        start = start + i
        left = left + i
        t[#t + 1] = tmpString
    end
    return t
end
function get_len(_str)
    local _table=change(_str)
    local _len=#_table
    return _len
end
function isCanInput(_str)
    local _table=change(_str)
    for k,v in ipairs(_table) do
            local _num=string.byte(v,1,string.len(v))
            cclog("_num-->".._num)
            if _num~=32 or _num~=226 then
            end
        end
end
function check(_str)
	
end
function get_edit_box(parameters)
	
end
function get_event()
    return function (strEventName,pSender)

        local _str=pSender:getText()
        local _table=change(_str)
            local _final=""
            for k,v in ipairs(_table) do
                local _num=string.byte(v,1,string.len(v))
            if _num~=32 and _num~=226 then
                    _final=_final..v
                end
            end
            if strEventName == "ended" or strEventName == "return" then
                pSender:setText(_final)
            end
        return 
--        table_out("_table",_table)
--        local _final=""
--        for k,v in ipairs(_table) do
--            local _num=string.byte(v,1,string.len(v))
--            cclog("_num-->".._num)
----            if k<_len and _num~=32 and _num~=226 then
--            if k<=_len then
--                _final=_final..v
--            end
--        end
--        local  strFmt
--        if strEventName == "began" then
----            strFmt = string.format("editBox %p DidBegin !", edit)
----            print(strFmt)
--        elseif strEventName == "ended" then
----            strFmt = string.format("editBox %p DidEnd !", edit)
----            print(strFmt)
--            pSender:setText(_final)
--        elseif strEventName == "return" then
--            pSender:setText(_final)
--        elseif strEventName == "changed" then
--            strFmt = string.format("text: %s ",_final)
--            
----            if _table~=nil and #_table>=_len then
----            _mes=_final
----            pSender:setText(_final)
----            end
--        end
--        cclog("".._final)
--        
    end
end

