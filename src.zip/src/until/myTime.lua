module("myTime",package.seeall)
--Lua 实现倒计时功能  
local scheduler = CCDirector:sharedDirector():getScheduler()  
local run_logic = nil  
  
--时 分 秒 数值  
local hour = 1  
local minute = 0  
local second = 0  
-- local _nodeTime=nil
--将int类型转换为string类型  
hour = hour..""  
minute = minute..""  
second = second..""  
local resultTime=''
local _string=nil
local _fun_id=nil
--倒计时更新函数  
local function anticlockwiseUpdate()  
    -- local time = mainLayer:getChildByTag(123)  
    -- time = tolua.cast(time,"CCLabelTTF")  
  
    second = second-1  
    if second == -1 then  
        if minute ~= -1 or hour ~= -1 then  
            minute = minute-1  
            second = 59  
            if minute == -1 then  
                if hour ~= -1 then  
                    hour = hour-1  
                    minute = 59  
                    if hour == -1 then  
                        --倒计时结束停止更新  
                        if run_logic ~= nil then  
                            scheduler:unscheduleScriptEntry(run_logic)  
                            run_logic = nil  
                        end  
                        second = 0  
                        minute = 0  
                        hour = 0  
                        time:setColor(ccc3(255,0,0)) --以红色标识结束  
                    end  
                end  
            end  
        end  
    end  
      
    second = second..""  
    minute = minute..""  
    hour = hour..""  
      
    if string.len(second) == 1 then  
        second = "0"..second  
    end  
      
    if string.len(minute) == 1 then  
        minute = "0"..minute  
    end  
      
    if string.len(hour) == 1 then  
        hour = "0"..hour  
    end  
  resultTime=""..hour..":"..minute..":"..second 
  if _fun_id~=nil then 
    _fun_id(true,resultTime.."/".._string)
  -- _nodeTime:setString(resultTime.."/".._string)
  end 
  -- print('time-->'..resultTime)
end  
function set_time( _time ,_fun)--分钟
    if run_logic~=nil then 
       scheduler:unscheduleScriptEntry(run_logic)  
       run_logic = nil  
    end
    -- body
    hour,minute=math.modf(_time/60)
    minute=_time-hour*60
    second=0
    if string.len(second) == 1 then  
        second = "0"..second  
    end  
      
    if string.len(minute) == 1 then  
        minute = "0"..minute  
    end  
      
    if string.len(hour) == 1 then  
        hour = "0"..hour  
    end  
    _string=""..hour..":"..minute..":"..second 
    run_logic = scheduler:scheduleScriptFunc(anticlockwiseUpdate,1,false)  
    if _fun~=nil then 
    _fun_id=_fun
    -- _nodeTime:setString(_string.."/".._string)
    _fun(true,_string.."/".._string)
    end
end
function get_time_result(  )
    -- body
    print('time------'..resultTime)
return resultTime

end
function Stop(  )
    -- body
    if run_logic~=nil then 
       scheduler:unscheduleScriptEntry(run_logic)  
       run_logic = nil  
       _fun_id=nil
    end
end

 