module("screenAdaption",package.seeall)
local sHeight = cc.Director:getInstance():getVisibleSize().height
local sWidth = cc.Director:getInstance():getVisibleSize().width
local factor -- 虚框调整参数
local dikuangPlistPath = nil
function AdapPos(object)-- 适配
local bi = 768/sWidth
local m = 1382/bi
local L_y = m-sHeight
--    local sz = self._scrollView:getContentSize()
--    self._scrollView:setContentSize(sz.width-L_x/2,sz.height)
--    self._scrollView:setPositionX(L_x/2)
--    self.m_scene_root:getChildByTag(10004):setPositionX(L_x/2)--回退按钮
--cclog("---{{{-->"..sHeight..":"..sWidth)
local bottom = L_y/2
local top = sHeight+L_y/2
if object ~= nil then
  top = sHeight+L_y/2-object:getContentSize().height
end
return bottom,top
end
